# SID Chrome Extension — Setup Guide

## Step 1: Download the two library files

The extension needs two JavaScript libraries bundled in the `lib/` folder.
Open each link below, right-click the page, choose "Save As", and save to the `lib/` folder:

1. **pako.min.js** — https://cdnjs.cloudflare.com/ajax/libs/pako/2.1.0/pako.min.js
   Save as: `SID-Chrome-Extension/lib/pako.min.js`

2. **jszip.min.js** — https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js
   Save as: `SID-Chrome-Extension/lib/jszip.min.js`

Your folder should look like this:

```
SID-Chrome-Extension/
  manifest.json
  sid.js
  lib/
    pako.min.js
    jszip.min.js
  icons/
    sid-16.png
    sid-48.png
    sid-128.png
```


## Step 2: Test locally first (before publishing)

1. Open Chrome and go to `chrome://extensions/`
2. Turn on **Developer mode** (toggle in the top right)
3. Click **"Load unpacked"**
4. Select the `SID-Chrome-Extension` folder
5. Go to Indeed employer dashboard and verify SID works
6. Once confirmed, turn Developer mode back off


## Step 3: Create a Chrome Web Store developer account

1. Go to https://chrome.google.com/webstore/devconsole
2. Sign in with your Google account
3. Pay the one-time $5 registration fee
4. Complete the account setup (name, email)


## Step 4: Package and upload

1. Create a ZIP of the extension folder:
   - Select ALL files inside `SID-Chrome-Extension/` (not the folder itself)
   - Right-click > "Compress" / "Send to > Compressed folder"
   - The ZIP should contain `manifest.json` at the root level (not inside a subfolder)

2. In the Chrome Web Store Developer Dashboard:
   - Click **"New Item"**
   - Upload your ZIP file
   - Fill in the listing details:
     - **Title:** SID - Smart Indeed Downloader
     - **Description:** Bulk download resumes from Indeed employer dashboard
     - **Category:** Productivity
     - **Language:** English
   - Under **Visibility**, select **"Unlisted"**
     (Only people with your direct link can find/install it)
   - Upload a screenshot (take one of SID running on Indeed)
   - Click **"Submit for review"**

3. Review usually takes 1-3 business days. You'll get an email when approved.


## Step 5: Share with vendors

Once approved, you'll get a Chrome Web Store link like:
`https://chrome.google.com/webstore/detail/sid-smart-indeed-downloader/[extension-id]`

Send this link to your vendors. They click it, click "Add to Chrome", done.
This also works for Microsoft Edge users — Edge installs Chrome extensions directly.


## Step 6: Push updates

When you edit `sid.js` and want to push an update:

1. Bump the version in `manifest.json` (e.g., `"5.5.0"` -> `"5.5.1"`)
2. Re-ZIP the folder (same as Step 4)
3. Go to Chrome Web Store Developer Dashboard
4. Click on your extension > **"Package"** tab > **"Upload new package"**
5. Upload the new ZIP and submit

Chrome auto-updates extensions every few hours. Your vendors will get the
update automatically — they don't need to do anything.


## Notes

- **Edge compatibility:** Works on Microsoft Edge automatically. Edge users can
  install directly from the Chrome Web Store link.

- **Updating the code:** When you change `sid.js`, always bump the version in
  `manifest.json` too, otherwise Chrome won't recognize it as an update.

- **Testing changes locally:** You can test changes before publishing by loading
  the unpacked extension (Step 2). Click the refresh icon on the extension card
  in `chrome://extensions/` after making changes.
