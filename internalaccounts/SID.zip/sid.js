(function() {
  'use strict';

  // ================================================
  // CONFIG
  // ================================================
  const DELAY_BETWEEN_MS   = 500;   // pause between fetches — fast but safe for Indeed's API
  const LOAD_MORE_PAUSE_MS = 1500;  // pause after clicking "Load more"
  const MAX_EMPTY_LOADS    = 3;     // stop if "Load more" succeeds but no new IDs appear this many times

  // ================================================
  // IndexedDB Storage Layer
  // ================================================
  const DB_NAME = 'SID_Resumes';
  const DB_VERSION = 2;
  const STORE_NAME = 'resumes';
  const CSV_STORE = 'csvdata';

  async function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onerror = () => reject(new Error(`IndexedDB open failed: ${req.error.message}`));
      req.onsuccess = () => resolve(req.result);
      req.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
        if (!db.objectStoreNames.contains(CSV_STORE)) {
          db.createObjectStore(CSV_STORE);
        }
      };
    });
  }

  // CSV storage in IndexedDB (avoids localStorage quota issues)
  // ================================================
  // Job data store — ALL per-job state lives in IndexedDB (no localStorage)
  // Each record: { jobKey, done:[], skip:[], rows:[], savedDate, savedAt }
  // ================================================
  async function saveJobData(jobKey, data) {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(CSV_STORE, 'readwrite');
        const store = tx.objectStore(CSV_STORE);
        store.put({
          jobKey,
          done: data.done || [],
          skip: data.skip || [],
          rows: data.rows || [],
          savedDate: data.savedDate || toEasternDateStr(),
          savedAt: Date.now()
        }, jobKey);
        tx.oncomplete = () => { db.close(); resolve(); };
        tx.onerror = () => reject(tx.error);
      });
    } catch (e) {
      console.warn('[SID] IndexedDB saveJobData failed:', e.message);
    }
  }

  async function loadJobData(jobKey) {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(CSV_STORE, 'readonly');
        const store = tx.objectStore(CSV_STORE);
        const req = store.get(jobKey);
        req.onsuccess = () => resolve(req.result || null);
        tx.oncomplete = () => db.close();
        tx.onerror = () => reject(tx.error);
      });
    } catch (e) {
      console.warn('[SID] IndexedDB loadJobData failed:', e.message);
      return null;
    }
  }

  async function getAllJobData() {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(CSV_STORE, 'readonly');
        const store = tx.objectStore(CSV_STORE);
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        tx.oncomplete = () => db.close();
        tx.onerror = () => reject(tx.error);
      });
    } catch (e) {
      console.warn('[SID] IndexedDB getAllJobData failed:', e.message);
      return [];
    }
  }

  async function deleteJobData(jobKey) {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(CSV_STORE, 'readwrite');
        const store = tx.objectStore(CSV_STORE);
        store.delete(jobKey);
        tx.oncomplete = () => { db.close(); resolve(); };
        tx.onerror = () => reject(tx.error);
      });
    } catch (e) {
      console.warn('[SID] IndexedDB deleteJobData failed:', e.message);
    }
  }

  async function clearAllJobData() {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(CSV_STORE, 'readwrite');
        const store = tx.objectStore(CSV_STORE);
        store.clear();
        tx.oncomplete = () => { db.close(); resolve(); };
        tx.onerror = () => reject(tx.error);
      });
    } catch (e) {
      console.warn('[SID] IndexedDB clearAllJobData failed:', e.message);
    }
  }

  // Aliases for backward-compat with code that calls these names
  // saveCSV alias — only safe to call for the CURRENT job (uses in-memory downloaded/skipped)
  const saveCSV = (jobKey, rows, savedDate) => {
    if (jobKey !== KEY) {
      // Different job — save CSV rows only, don't overwrite that job's done/skip
      return saveJobData(jobKey, { rows, savedDate });
    }
    return saveJobData(jobKey, { rows, done: [...downloaded], skip: [...skipped], savedDate });
  };
  const loadCSV = loadJobData;
  const getAllCSV = getAllJobData;
  const deleteCSV = deleteJobData;
  const clearAllCSV = clearAllJobData;

  async function storeResume(jobKey, candidateId, filename, blob, legacyId) {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const key = `${jobKey}::${candidateId}`;
        const value = {
          jobKey: jobKey,
          candidateId: candidateId,
          legacyId: legacyId || candidateId,
          filename: filename,
          blob: blob,
          timestamp: Date.now()
        };
        const req = store.put(value, key);
        req.onerror = () => reject(new Error(`Store put failed: ${req.error.message}`));
        req.onsuccess = () => resolve();
        tx.oncomplete = () => db.close();
        tx.onerror = () => reject(new Error(`Transaction failed: ${tx.error.message}`));
      });
    } catch (e) {
      console.warn('[SID] IndexedDB store failed, falling back to localStorage:', e.message);
    }
  }

  async function getResumesForJob(jobKey) {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const req = store.getAll();
        req.onerror = () => reject(new Error(`Store getAll failed: ${req.error.message}`));
        req.onsuccess = () => {
          const results = req.result.filter(r => r.jobKey === jobKey);
          resolve(results);
        };
        tx.oncomplete = () => db.close();
        tx.onerror = () => reject(new Error(`Transaction failed: ${tx.error.message}`));
      });
    } catch (e) {
      console.warn('[SID] IndexedDB getResumesForJob failed:', e.message);
      return [];
    }
  }

  async function getAllResumes() {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const req = store.getAll();
        req.onerror = () => reject(new Error(`Store getAll failed: ${req.error.message}`));
        req.onsuccess = () => resolve(req.result || []);
        tx.oncomplete = () => db.close();
        tx.onerror = () => reject(new Error(`Transaction failed: ${tx.error.message}`));
      });
    } catch (e) {
      console.warn('[SID] IndexedDB getAllResumes failed:', e.message);
      return [];
    }
  }

  async function clearResumesForJob(jobKey) {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const req = store.getAll();
        req.onerror = () => reject(new Error(`Store getAll failed: ${req.error.message}`));
        req.onsuccess = () => {
          const results = req.result;
          for (const r of results) {
            if (r.jobKey === jobKey) {
              const key = `${jobKey}::${r.candidateId}`;
              store.delete(key);
            }
          }
        };
        tx.oncomplete = () => {
          db.close();
          resolve();
        };
        tx.onerror = () => reject(new Error(`Transaction failed: ${tx.error.message}`));
      });
    } catch (e) {
      console.warn('[SID] IndexedDB clearResumesForJob failed:', e.message);
    }
  }

  async function getAllJobKeys() {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const req = store.getAll();
        req.onerror = () => reject(new Error(`Store getAll failed: ${req.error.message}`));
        req.onsuccess = () => {
          const results = req.result;
          const keys = [...new Set(results.map(r => r.jobKey))];
          resolve(keys);
        };
        tx.oncomplete = () => db.close();
        tx.onerror = () => reject(new Error(`Transaction failed: ${tx.error.message}`));
      });
    } catch (e) {
      console.warn('[SID] IndexedDB getAllJobKeys failed:', e.message);
      return [];
    }
  }

  // ================================================
  // Persistent state (survives reloads) — keyed per job listing
  // ================================================
  // Diagnostic trace of every jobKey decision. Inspect from the page console with:
  //   copy(JSON.stringify(window._sidJobKeyTrace, null, 2))
  // Used to diagnose jobKey conflation (different Indeed postings collapsing into
  // the same SID jobKey) and stale-key drift (same posting deriving different keys
  // across sessions). Keeps the most recent 200 decisions to bound memory.
  if (!window._sidJobKeyTrace) window._sidJobKeyTrace = [];

  function getJobKey() {
    const params = new URLSearchParams(window.location.search);

    // legacyJobId is the ONLY stable identifier across Indeed SPA navigations.
    // The `l` param changes every time you navigate to the same job.
    // The `selectedJobs` param is only present on some loads.
    // legacyJobId stays the same for the same job, always.
    const legacyJobId = params.get('legacyJobId') || '';
    const selectedJobs = params.get('selectedJobs') || '';
    const listId = params.get('l') || params.get('id') || '';

    console.log(`[SID] getJobKey: legacyJobId="${legacyJobId}" l="${listId}" selectedJobs="${selectedJobs ? '(present)' : ''}" URL="${window.location.pathname}${window.location.search.substring(0, 80)}..."`);
    const _traceEntry = {
      ts: new Date().toISOString(),
      url: window.location.pathname + window.location.search,
      legacyJobId, listId,
      selectedJobs: selectedJobs ? selectedJobs.substring(0, 80) + '...' : '',
      listQueryRaw: (params.get('listQuery') || '').substring(0, 80) + '...',
      resolved: null,
      source: null
    };

    function _record(key, source) {
      _traceEntry.resolved = key;
      _traceEntry.source = source;
      window._sidJobKeyTrace.push(_traceEntry);
      if (window._sidJobKeyTrace.length > 200) window._sidJobKeyTrace.shift();
      return key;
    }

    // 1. Best: legacyJobId — stable across all navigations
    if (legacyJobId) {
      const key = `sid_dl_${legacyJobId}`;
      console.log(`[SID] getJobKey: → "${key}" (from legacyJobId)`);
      return _record(key, 'legacyJobId');
    }

    // 2. Try extracting legacyJobId from listQuery param (it's embedded in the base64)
    const listQuery = params.get('listQuery') || '';
    if (listQuery) {
      try {
        const decoded = atob(listQuery);
        const decodedParams = new URLSearchParams(decodeURIComponent(decoded));
        const embeddedId = decodedParams.get('id') || '';
        if (embeddedId) {
          const key = `sid_dl_${embeddedId}`;
          console.log(`[SID] getJobKey: → "${key}" (from listQuery.id)`);
          return _record(key, 'listQuery.id');
        }
      } catch (e) { /* not decodable */ }
    }

    // 3. Decode selectedJobs base64 IRI to extract stable job ID
    if (selectedJobs) {
      try {
        const decoded = atob(selectedJobs);
        const lastSlash = decoded.lastIndexOf('/');
        if (lastSlash !== -1 && lastSlash < decoded.length - 1) {
          const stableId = decoded.substring(lastSlash + 1);
          const key = `sid_dl_${stableId}`;
          console.log(`[SID] getJobKey: → "${key}" (from selectedJobs decode: "${decoded}")`);
          return _record(key, 'selectedJobs');
        }
      } catch (e) { /* not base64 */ }
    }

    // 4. Last resort: l/id param (WARNING: not stable across navigations)
    if (listId) {
      const key = `sid_dl_${listId}`;
      console.log(`[SID] getJobKey: → "${key}" (from l/id — NOT STABLE)`);
      return _record(key, 'l/id (UNSTABLE)');
    }

    console.log(`[SID] getJobKey: no params found, using default`);
    return _record('sid_dl_default', 'default');
  }

  let KEY = getJobKey();

  console.log(`[SID] INIT: KEY="${KEY}" — all state in IndexedDB`);

  // One-time migration: convert ALL old long sid_dl_ keys to short format.
  // Old keys were full base64 (sid_dl_aXJpOi8v...) or sanitized IRIs (sid_dl_iri___apis_...).
  // New keys use just the last path segment (sid_dl_1270).
  // Must migrate BOTH localStorage AND IndexedDB jobKey values.
  function _deriveShortKey(oldKey) {
    const suffix = oldKey.substring(7); // strip 'sid_dl_'
    // Already short? Skip.
    if (suffix.length < 30) return null;
    // Try decoding as base64 → extract last path segment
    try {
      const decoded = atob(suffix);
      const lastSlash = decoded.lastIndexOf('/');
      if (lastSlash !== -1 && lastSlash < decoded.length - 1) {
        return `sid_dl_${decoded.substring(lastSlash + 1)}`;
      }
    } catch (e) { /* not base64 */ }
    // Try sanitized IRI pattern: ...EmployerJob_XXXX or ...HostedJob_XXXX
    const match = suffix.match(/_([^_]+)$/);
    if (match) return `sid_dl_${match[1]}`;
    return null;
  }

  // Migrate IndexedDB resume blob jobKey values from old long keys to short keys
  (async function migrateResumeKeys() {
    try {
      const db = await openDB();
      const readTx = db.transaction(STORE_NAME, 'readonly');
      const readStore = readTx.objectStore(STORE_NAME);
      const [allKeys, allVals] = await new Promise((res, rej) => {
        let keys, vals;
        const kReq = readStore.getAllKeys();
        const vReq = readStore.getAll();
        kReq.onsuccess = () => { keys = kReq.result; if (vals) res([keys, vals]); };
        vReq.onsuccess = () => { vals = vReq.result; if (keys) res([keys, vals]); };
        kReq.onerror = rej; vReq.onerror = rej;
      });
      const toMigrate = [];
      for (let i = 0; i < allVals.length; i++) {
        const entry = allVals[i];
        if (!entry.jobKey || !entry.jobKey.startsWith('sid_dl_')) continue;
        const newJobKey = _deriveShortKey(entry.jobKey);
        if (newJobKey && newJobKey !== entry.jobKey) {
          toMigrate.push({ oldStoreKey: allKeys[i], entry, newJobKey });
        }
      }
      if (toMigrate.length === 0) { db.close(); return; }
      const writeTx = db.transaction(STORE_NAME, 'readwrite');
      const writeStore = writeTx.objectStore(STORE_NAME);
      for (const { oldStoreKey, entry, newJobKey } of toMigrate) {
        writeStore.delete(oldStoreKey);
        const newEntry = { ...entry, jobKey: newJobKey };
        writeStore.put(newEntry, `${newJobKey}::${entry.candidateId}`);
      }
      await new Promise((res, rej) => { writeTx.oncomplete = () => res(); writeTx.onerror = rej; });
      db.close();
      console.log(`[SID] Migrated ${toMigrate.length} IndexedDB resume entries to short keys`);
    } catch (e) {
      console.warn('[SID] Resume key migration failed (non-fatal):', e.message);
    }
  })();

  // ================================================
  // ALL state lives in IndexedDB — NO localStorage for SID data
  // In-memory sets are the source of truth during a session;
  // persist() writes them to IndexedDB with a short debounce.
  // ================================================
  let downloaded = new Set();
  let skipped    = new Set();
  let _persistTimer = null;

  function persist() {
    // Debounce writes to IndexedDB — batch every 1 second
    if (_persistTimer) clearTimeout(_persistTimer);
    _persistTimer = setTimeout(() => {
      _persistTimer = null;
      console.log(`[SID] persist(): saving ${downloaded.size} done, ${skipped.size} skipped, ${csvRows.length} csv under KEY="${KEY}"`);
      saveJobData(KEY, {
        done: [...downloaded],
        skip: [...skipped],
        rows: csvRows,
        savedDate: toEasternDateStr()
      });
    }, 1000);
  }

  // Force-flush — call before zip download or job switch
  function flushCSV() {
    if (_persistTimer) { clearTimeout(_persistTimer); _persistTimer = null; }
    console.log(`[SID] flushCSV(): force-saving ${downloaded.size} done, ${skipped.size} skipped, ${csvRows.length} csv under KEY="${KEY}"`);
    saveJobData(KEY, {
      done: [...downloaded],
      skip: [...skipped],
      rows: csvRows,
      savedDate: toEasternDateStr()
    });
  }

  // Flush on page close so debounced data isn't lost
  window.addEventListener('beforeunload', () => {
    if (_persistTimer) {
      clearTimeout(_persistTimer);
      _persistTimer = null;
      // navigator.sendBeacon can't write to IndexedDB, but we can fire-and-forget
      saveJobData(KEY, {
        done: [...downloaded],
        skip: [...skipped],
        rows: csvRows,
        savedDate: toEasternDateStr()
      });
    }
  });

  // One-time migration: move any remaining localStorage SID data into IndexedDB
  (function migrateLocalStorageToIDB() {
    const sidKeys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith('sid_dl_')) sidKeys.push(k);
    }
    if (sidKeys.length === 0) return;
    console.log(`[SID] Migrating ${sidKeys.length} localStorage key(s) to IndexedDB...`);
    for (const k of sidKeys) {
      try {
        const data = JSON.parse(localStorage.getItem(k));
        if (data && ((data.done && data.done.length > 0) || (data.skip && data.skip.length > 0))) {
          // Merge into IndexedDB — don't overwrite existing IDB data
          (async () => {
            const existing = await loadJobData(k);
            if (!existing || ((!existing.done || existing.done.length === 0) && (!existing.skip || existing.skip.length === 0))) {
              await saveJobData(k, {
                done: data.done || [],
                skip: data.skip || [],
                rows: (existing && existing.rows) || data.csv || [],
                savedDate: data.savedDate || toEasternDateStr()
              });
              console.log(`[SID] Migrated localStorage ${k} → IndexedDB (${(data.done||[]).length} done, ${(data.skip||[]).length} skip)`);
            }
          })();
        }
        localStorage.removeItem(k);
      } catch (e) { localStorage.removeItem(k); }
    }
  })();

  // Search IndexedDB for data saved under an old key that belongs to the current job.
  // Matches by checking if any entry's `done` array contains a candidate ID from the URL.
  async function _findAndMigrateOldData(targetKey) {
    const params = new URLSearchParams(window.location.search);
    const candidateId = params.get('id') || '';
    if (!candidateId || targetKey === 'sid_dl_default') return null;

    const allEntries = await getAllJobData();
    for (const entry of allEntries) {
      if (entry.jobKey === targetKey) continue;
      if (entry.done && entry.done.includes(candidateId)) {
        console.log(`[SID] Found old data under "${entry.jobKey}" → migrating to "${targetKey}" (matched candidate ${candidateId})`);
        await saveJobData(targetKey, { done: entry.done, skip: entry.skip, rows: entry.rows, savedDate: entry.savedDate });
        await deleteJobData(entry.jobKey);
        // Also update resume blob jobKeys
        try {
          const db = await openDB();
          const readTx = db.transaction(STORE_NAME, 'readonly');
          const readStore = readTx.objectStore(STORE_NAME);
          const [allKeys, allVals] = await new Promise((res, rej) => {
            let keys, vals;
            const kR = readStore.getAllKeys(); const vR = readStore.getAll();
            kR.onsuccess = () => { keys = kR.result; if (vals) res([keys, vals]); };
            vR.onsuccess = () => { vals = vR.result; if (keys) res([keys, vals]); };
            kR.onerror = rej; vR.onerror = rej;
          });
          const toMigrate = [];
          for (let i = 0; i < allVals.length; i++) {
            if (allVals[i].jobKey === entry.jobKey) toMigrate.push({ oldKey: allKeys[i], entry: allVals[i] });
          }
          if (toMigrate.length > 0) {
            const writeTx = db.transaction(STORE_NAME, 'readwrite');
            const writeStore = writeTx.objectStore(STORE_NAME);
            for (const m of toMigrate) {
              writeStore.delete(m.oldKey);
              m.entry.jobKey = targetKey;
              writeStore.put(m.entry, `${targetKey}::${m.entry.candidateId}`);
            }
            await new Promise(r => { writeTx.oncomplete = r; });
            console.log(`[SID] Migrated ${toMigrate.length} resume blobs to new key`);
          }
          db.close();
        } catch (e) { console.warn('[SID] Resume blob migration failed (non-fatal):', e.message); }
        return { done: entry.done, skip: entry.skip, rows: entry.rows, savedDate: entry.savedDate };
      }
    }
    return null;
  }

  // Re-check the key when URL changed (navigated to different job)
  async function refreshStorageKey() {
    const newKey = getJobKey();
    if (newKey !== KEY) {
      const oldKey = KEY;
      // Persist current job's data under current KEY before switching
      flushCSV();
      console.log(`[SID] Job changed: ${oldKey} → ${newKey}`);
      KEY = newKey;
      // Load state from IndexedDB for the new job
      let data = await loadJobData(KEY);
      // If no data found, try migrating from an old unstable key
      if (!data || (!data.done?.length && !data.skip?.length)) {
        data = await _findAndMigrateOldData(KEY);
      }
      downloaded = new Set((data && data.done) || []);
      skipped = new Set((data && data.skip) || []);
      csvRows = (data && data.rows) || [];
      console.log(`[SID] Loaded state for ${KEY}: ${downloaded.size} done, ${skipped.size} skipped, ${csvRows.length} csv rows`);
    }
  }

  // ================================================
  // Auto-cleanup: purge job data older than 7 days (all in IndexedDB)
  // ================================================
  (async function autoCleanup() {
    try {
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - 7);
      const cutoffStr = toEasternDateStr(cutoff.getTime());

      // 1. Find stale job data entries in IndexedDB csvdata store
      const allJobs = await getAllJobData();
      const staleKeys = new Set();
      for (const entry of allJobs) {
        if (entry.savedDate && entry.savedDate < cutoffStr) {
          staleKeys.add(entry.jobKey);
          await deleteJobData(entry.jobKey);
        }
      }
      if (staleKeys.size === 0) return;
      console.log(`[SID] Auto-cleanup: removed ${staleKeys.size} job(s) older than 7 days`);

      // 2. Remove matching resume blobs from IndexedDB
      const db = await openDB();
      const readTx = db.transaction(STORE_NAME, 'readonly');
      const readStore = readTx.objectStore(STORE_NAME);
      const [allKeys, allVals] = await new Promise((res, rej) => {
        let keys, vals;
        const kR = readStore.getAllKeys(); const vR = readStore.getAll();
        kR.onsuccess = () => { keys = kR.result; if (vals) res([keys, vals]); };
        vR.onsuccess = () => { vals = vR.result; if (keys) res([keys, vals]); };
        kR.onerror = rej; vR.onerror = rej;
      });
      const toDelete = [];
      for (let i = 0; i < allVals.length; i++) {
        if (staleKeys.has(allVals[i].jobKey)) toDelete.push(allKeys[i]);
      }
      if (toDelete.length > 0) {
        const writeTx = db.transaction(STORE_NAME, 'readwrite');
        const writeStore = writeTx.objectStore(STORE_NAME);
        toDelete.forEach(k => writeStore.delete(k));
        await new Promise((res) => { writeTx.oncomplete = () => res(); });
        console.log(`[SID] Auto-cleanup: removed ${toDelete.length} resume blob(s)`);
      }
      db.close();
    } catch (e) {
      console.warn('[SID] Auto-cleanup failed (non-fatal):', e.message);
    }
  })();

  // ================================================
  // Helpers
  // ================================================
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const randomWait = (min, max) => wait(Math.floor(Math.random() * (max - min + 1)) + min);

  function getCSRFToken() {
    // Indeed (June 2026) removed the CSRF cookie and now exposes the token as a
    // page global (window.csrf). We run in world:MAIN, so we can read it directly.
    for (const g of ['csrf', 'csrfToken', 'indeedCsrfToken', 'indeedcsrftoken', '_csrf', 'CSRF']) {
      try {
        const v = window[g];
        if (typeof v === 'string' && /^[a-f0-9]{16,}$/i.test(v)) return v;
      } catch (e) {}
    }
    const csrfMatch = document.cookie.match(/(?:^|;\s*)CSRF=([a-f0-9]+)/);
    if (csrfMatch) return csrfMatch[1];
    const cookies = document.cookie.split(';').map(c => c.trim());
    for (const c of cookies) {
      const [name, ...rest] = c.split('=');
      const val = rest.join('=').trim();
      if (!val) continue;
      const decoded = decodeURIComponent(val);
      if (/csrf|xsrf|token/i.test(name.trim()) && decoded.length >= 20) return decoded;
    }
    for (const c of cookies) {
      const [, val] = c.split('=').map(s => s.trim());
      if (val && /^[a-f0-9]{32}$/i.test(decodeURIComponent(val))) return decodeURIComponent(val);
    }
    const dlLink = document.querySelector('a[data-testid="download-resume-inline"]');
    if (dlLink) {
      const href = dlLink.href || dlLink.getAttribute('href') || '';
      const hm = href.match(/indeedcsrftoken=([a-f0-9]+)/i);
      if (hm) return hm[1];
    }
    for (const a of document.querySelectorAll('a[href*="csrftoken"], form input[name*="csrf"]')) {
      const val = (a.href || a.value || '').match(/csrftoken=([a-f0-9]+)/i);
      if (val) return val[1];
    }
    console.warn('[SID] CSRF token not found in cookies, links, or form fields');
    return null;
  }

  function getTotalFromPage() {
    // Check candidate-specific selectors first
    const selectors = [
        '[data-testid="candidate-list-header"]',
        '[data-testid="candidates-count"]',
        '.ia-candidates-count',
        'nav[aria-label*="pagination"]'
    ];
    for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) {
            const match = el.textContent.match(/(\d+)\s+of\s+(\d+)/);
            if (match) return parseInt(match[2], 10);
        }
    }
    // Fallback: try to find "X of Y" in body text
    const allText = document.body.innerText;
    const matches = allText.matchAll(/(\d+)\s+of\s+(\d+)/g);
    for (const m of matches) {
        const val = parseInt(m[2], 10);
        if (val < 5) continue;
        return val;
    }
    const fallback = allText.match(/(\d+)\s+of\s+(\d+)/);
    return fallback ? parseInt(fallback[2], 10) : 0;
  }

  function getCandidateIds() {
    // Return IDs of all candidates on the current page (visible in DOM)
    const ids = [];
    document.querySelectorAll('li[data-testid="CandidateListItem"][id^="candidate-tab-"]').forEach(li => {
      const id = li.id.replace(/^candidate-tab-/, '');
      if (id) ids.push(id);
    });
    return ids;
  }

  function getNameForId(id) {
    const li = document.querySelector(`#candidate-tab-${id}`);
    if (!li) return '';
    const link = li.querySelector('a');
    if (link) {
      const aria = link.getAttribute('aria-label') || '';
      if (aria && !(/ago|applicant|hour|minute|day/i.test(aria))) return aria.trim();
    }
    const walker = document.createTreeWalker(li, NodeFilter.SHOW_ELEMENT, null, false);
    let node;
    while ((node = walker.nextNode())) {
      if (node.children.length > 0) continue;
      const txt = node.textContent.trim();
      if (!txt || txt.length < 2 || txt.length > 50) continue;
      if (/\d+\s*(minute|hour|day|week|month)s?\s*ago/i.test(txt)) continue;
      if (/^new\s*applicant/i.test(txt)) continue;
      if (/^(reviewing|contacting|interviewing|hired|rejected|new)$/i.test(txt)) continue;
      if (/accepts\s*push/i.test(txt)) continue;
      if (/load\s*more/i.test(txt)) continue;
      return txt;
    }
    // Fallback: split li text by newlines and find first plausible name
    const text = li.textContent.trim();
    const lines = text.split(/\n/).map(l => l.trim()).filter(Boolean);
    for (const line of lines) {
      if (line.length < 2 || line.length > 50) continue;
      if (/ago|applicant|accepts|load more/i.test(line)) continue;
      return line;
    }
    return '';
  }

  function toEasternDateStr(timestamp) {
    const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
    const formatter = new Intl.DateTimeFormat('en-US', { ...options, timeZone: 'America/New_York' });
    const parts = formatter.formatToParts(timestamp ? new Date(timestamp) : new Date());
    const year = parts.find(p => p.type === 'year')?.value;
    const month = parts.find(p => p.type === 'month')?.value;
    const day = parts.find(p => p.type === 'day')?.value;
    return `${year}-${month}-${day}`;
  }

  function playCompletionChime() {
    try {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const notes = [523.25, 659.25, 783.99]; // C, E, G
      for (let i = 0; i < notes.length; i++) {
        const osc = audioContext.createOscillator();
        const gain = audioContext.createGain();
        osc.connect(gain);
        gain.connect(audioContext.destination);
        osc.frequency.value = notes[i];
        osc.type = 'sine';
        const startTime = audioContext.currentTime + (i * 0.15);
        gain.gain.setValueAtTime(0.3, startTime);
        gain.gain.exponentialRampToValueAtTime(0.01, startTime + 0.3);
        osc.start(startTime);
        osc.stop(startTime + 0.3);
      }
    } catch (e) { /* audio not supported */ }
  }

  function normalizeToASCII(str) {
    if (!str) return '';
    // Decompose unicode, strip combining diacritical marks: "Peña" → "Pena", "José" → "Jose"
    let result = str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    // Smart quotes → straight quotes
    result = result.replace(/[\u2018\u2019\u201A\u201B]/g, "'");
    result = result.replace(/[\u201C\u201D\u201E\u201F]/g, '"');
    // En-dash, em-dash, minus sign → regular hyphen
    result = result.replace(/[\u2013\u2014\u2015\u2212]/g, '-');
    // Other common unicode → ASCII
    result = result.replace(/\u2026/g, '...');
    result = result.replace(/\u00A0/g, ' ');
    result = result.replace(/\u2022/g, '-');
    return result;
  }

  function cleanName(name) {
    if (!name) return '';
    // First normalize unicode to ASCII (accents, smart quotes, dashes)
    let cleaned = normalizeToASCII(name);
    // Strip emojis and special unicode symbols (keep letters, numbers, basic punctuation)
    cleaned = cleaned.replace(/[^\p{L}\p{N}\s'\-.]/gu, '');
    // Strip name suffixes (Jr, Sr, II, III, IV, V, etc.) from end of name
    cleaned = cleaned.replace(/[,\s]+(?:Jr|Sr|Junior|Senior|[IVX]{2,}|2nd|3rd|4th|Esq)\.?\s*$/gi, '');
    // Strip common professional credentials — remove the word, then clean up
    const credentialWords = /\b(?:BSN|RN|LPN|LVN|CNA|CMA|CCM|NP|PA-C|LCSW|LMSW|MSW|LSW|APRN|FNP|DNP|PhD|PharmD|DO|MD|MBA|MPA|MPH|MHA|JD|ESQ|CPA|PMP|SHRM-CP|SHRM-SCP|SPHR|PHR|CCRN|CRNA|OTR|COTA|PTA|DPT|RT|RRT|RHIT|RHIA|RD|CDN|CHW|EMT|AEMT|NRP)\b/gi;
    cleaned = cleaned.replace(credentialWords, '');
    // Clean up leftover commas, extra whitespace, leading/trailing junk
    cleaned = cleaned.replace(/\s*,\s*/g, ' ').replace(/\s{2,}/g, ' ').replace(/^[\s,.\-]+|[\s,.\-]+$/g, '').trim();
    // Normalize spaces around hyphens: "Jackson -Frazier" → "Jackson-Frazier"
    cleaned = cleaned.replace(/\s*-\s*/g, '-').replace(/^-+|-+$/g, '');
    if (!cleaned) return name.trim(); // fallback to original if we stripped everything
    // Proper case: handle hyphenated names, apostrophes, "Mc" prefix
    return cleaned.split(/\s+/).map(word => {
      if (!word) return '';
      // Handle hyphenated names: "ford-grice" → "Ford-Grice"
      if (word.includes('-')) {
        return word.split('-').map(part => properCaseWord(part)).join('-');
      }
      return properCaseWord(word);
    }).join(' ');
  }

  function properCaseWord(w) {
    if (!w) return '';
    const lower = w.toLowerCase();
    // Handle Mc prefix: "mcdonald" → "McDonald"
    if (lower.startsWith('mc') && lower.length > 2) {
      return 'Mc' + lower.charAt(2).toUpperCase() + lower.slice(3);
    }
    // Handle O' prefix: "o'brien" → "O'Brien"
    if (lower.startsWith("o'") && lower.length > 2) {
      return "O'" + lower.charAt(2).toUpperCase() + lower.slice(3);
    }
    // Handle mid-word apostrophes: "te'anna" → "Te'Anna"
    if (lower.includes("'") && !lower.startsWith("o'")) {
      const parts = lower.split("'");
      return parts.map(p => p ? p.charAt(0).toUpperCase() + p.slice(1) : '').join("'");
    }
    return lower.charAt(0).toUpperCase() + lower.slice(1);
  }

  function properCaseCity(city) {
    if (!city) return '';
    return city.split(/\s+/).map(w => {
      if (!w) return '';
      if (w.includes('-')) {
        return w.split('-').map(p => p ? p.charAt(0).toUpperCase() + p.slice(1).toLowerCase() : '').join('-');
      }
      return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
    }).join(' ');
  }

  function parseLocation(loc, candidateCountry) {
    if (!loc) return { city: '', state: '', zip: '' };

    // Full state/province name → 2-letter code mapping
    const stateNames = {
      'alabama':'AL','alaska':'AK','arizona':'AZ','arkansas':'AR','california':'CA',
      'colorado':'CO','connecticut':'CT','delaware':'DE','florida':'FL','georgia':'GA',
      'hawaii':'HI','idaho':'ID','illinois':'IL','indiana':'IN','iowa':'IA','kansas':'KS',
      'kentucky':'KY','louisiana':'LA','maine':'ME','maryland':'MD','massachusetts':'MA',
      'michigan':'MI','minnesota':'MN','mississippi':'MS','missouri':'MO','montana':'MT',
      'nebraska':'NE','nevada':'NV','new hampshire':'NH','new jersey':'NJ','new mexico':'NM',
      'new york':'NY','north carolina':'NC','north dakota':'ND','ohio':'OH','oklahoma':'OK',
      'oregon':'OR','pennsylvania':'PA','rhode island':'RI','south carolina':'SC',
      'south dakota':'SD','tennessee':'TN','texas':'TX','utah':'UT','vermont':'VT',
      'virginia':'VA','washington':'WA','west virginia':'WV','wisconsin':'WI','wyoming':'WY',
      'district of columbia':'DC',
      'alberta':'AB','british columbia':'BC','manitoba':'MB','new brunswick':'NB',
      'newfoundland':'NL','newfoundland and labrador':'NL','nova scotia':'NS',
      'ontario':'ON','prince edward island':'PE','quebec':'QC','saskatchewan':'SK',
      'northwest territories':'NT','nunavut':'NU','yukon':'YT'
    };

    // Canadian city → province mapping for when only city name is available
    const canadianCities = {
      // Ontario
      'toronto':'ON','mississauga':'ON','brampton':'ON','ottawa':'ON','hamilton':'ON',
      'london':'ON','kitchener':'ON','windsor':'ON','oshawa':'ON','barrie':'ON',
      'kingston':'ON','guelph':'ON','cambridge':'ON','waterloo':'ON','brantford':'ON',
      'pickering':'ON','ajax':'ON','whitby':'ON','markham':'ON','vaughan':'ON',
      'richmond hill':'ON','newmarket':'ON','scarborough':'ON','etobicoke':'ON',
      'kanata':'ON','stittsville':'ON','almonte':'ON','milton':'ON','caledon':'ON',
      'port colborne':'ON','north york':'ON','north bay':'ON','sudbury':'ON',
      'peterborough':'ON','owen sound':'ON','cornwall':'ON','nepean':'ON',
      'oakville':'ON','burlington':'ON','concord':'ON','maple':'ON','unionville':'ON',
      'stouffville':'ON','bolton':'ON','georgetown':'ON','bowmanville':'ON',
      'angus':'ON','arthur':'ON','beeton':'ON','chelmsford':'ON','erin':'ON',
      'fergus':'ON','keswick':'ON','lansdowne':'ON','leamington':'ON','lindsay':'ON',
      'mcgregor':'ON','niagara falls':'ON','stoney creek':'ON','stratford':'ON',
      'sutton':'ON','tiny':'ON','trenton':'ON','waubaushene':'ON','welland':'ON',
      'woodstock':'ON','crystal beach':'ON','st. catharines':'ON','catharines':'ON',
      'st catharines':'ON','archambault':'ON','alexandria':'ON',
      'elgin':'ON','st. marys':'ON','st marys':'ON','chatham-kent':'ON','chatham':'ON',
      'cobourg':'ON','collingwood':'ON','orillia':'ON','pembroke':'ON','brockville':'ON',
      // Quebec
      'montreal':'QC','quebec city':'QC','quebec':'QC','laval':'QC','gatineau':'QC',
      'longueuil':'QC','sherbrooke':'QC','levis':'QC','brossard':'QC',
      'salaberry-de-valleyfield':'QC','saint-marthe-sur-le-lac':'QC',
      'lachine':'QC','lasalle':'QC','dorval':'QC','pierrefonds':'QC',
      'dollard-des ormeaux':'QC','montreal nord':'QC','blainville':'QC',
      'chateauguay':'QC','beauharnois':'QC','mirabel':'QC','magog':'QC',
      'montmagny':'QC','saint-hippolyte':'QC','messines':'QC',
      'sainte-barbe':'QC','baie-sainte-anne':'NB',
      // British Columbia
      'vancouver':'BC','surrey':'BC','burnaby':'BC','victoria':'BC','kelowna':'BC',
      'richmond':'BC','north vancouver':'BC','langford':'BC','esquimalt':'BC',
      'saanich':'BC','maple ridge':'BC','kamloops':'BC','chilliwack':'BC',
      'parksville':'BC','barriere':'BC',
      // Alberta
      'calgary':'AB','edmonton':'AB','red deer':'AB','lethbridge':'AB','leduc':'AB',
      'airdrie':'AB','beaumont':'AB','cold lake':'AB','vermilion':'AB','berwyn':'AB',
      // Manitoba
      'winnipeg':'MB','brandon':'MB','portage la prairie':'MB','landmark':'MB',
      'rorketon':'MB',
      // Saskatchewan
      'saskatoon':'SK','regina':'SK','warman':'SK','weyburn':'SK','cut knife':'SK',
      'moose jaw':'SK','prince albert':'SK','swift current':'SK','yorkton':'SK',
      // Nova Scotia
      'halifax':'NS','dartmouth':'NS','sydney':'NS','truro':'NS','hilden':'NS',
      'florence':'NS','lucasville':'NS','centreville':'NS','canning':'NS',
      'greenfield':'NS','ambrose':'NS',
      // New Brunswick
      'fredericton':'NB','moncton':'NB','saint john':'NB','bathurst':'NB',
      'riverview':'NB','boiestown':'NB',
      // Newfoundland
      'st. john\'s':'NL','corner brook':'NL','little catalina':'NL',
      'normans cove':'NL',
      // PEI / Territories
      'charlottetown':'PE',
      'whitehorse':'YT','yellowknife':'NT','iqaluit':'NU'
    };

    const isCanadian = (candidateCountry || '').toUpperCase() === 'CA';
    const allCodes = 'AL|AK|AZ|AR|CA|CO|CT|DE|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY|DC|AB|BC|MB|NB|NL|NS|NT|NU|ON|PE|QC|SK|YT';
    // Exclude "CA" from state matching for Canadian candidates (CA = their country, not California)
    const usStates = isCanadian ? allCodes.replace('CA|', '') : allCodes;
    const stateRegex = new RegExp(`\\b(${usStates})\\b`);

    // Strip street address components from a string
    function stripStreet(str) {
      if (!str) return str;
      // Remove leading house number (with optional unit like "307-45") + street name
      // Catches: "7470 Boul. Pie-Ix", "157 Legacy Glen Place", "232 Hill St S", "307-45 Twin Oaks Dr"
      let cleaned = str.replace(/^\d+[\-\d]*\s+.*/i, '').trim();
      // Remove leading "Rue/Boul/etc" without a number: "Rue Otawa" → "Otawa"
      if (!cleaned) cleaned = str.replace(/^(?:rue|boul\.?|boulevard|ave\.?|avenue|st\.?|street|rd\.?|road|dr\.?|drive|ch\.?|chemin)\s+/i, '').trim();
      return cleaned || str;
    }

    // Check if a string looks like a street address (starts with a number)
    function isStreetAddress(str) {
      return /^\d+[\-\d]*\s+/.test(str);
    }

    // Pre-clean the location string before parsing
    let cleaned = loc;

    // Bare US zip code: "60104" or "29466" — just a zip, no city or state
    if (/^\d{5}$/.test(cleaned.trim())) {
      return { city: '', state: '', zip: cleaned.trim() };
    }

    // Canadian postal code pattern (used in multiple checks below)
    const caPostalPat = '([A-Z]\\d[A-Z]\\s?\\d[A-Z]\\d)';

    // Handle pipe-separated format FIRST: "Canada | Manitoba | Landmark" → "Landmark, MB"
    // Must come before Canada-prefix check so pipes aren't blanked
    if (cleaned.includes('|')) {
      const pipeParts = cleaned.split('|').map(s => s.trim()).filter(Boolean);
      const filtered = pipeParts.filter(p => !/^(canada|united states|usa|us)$/i.test(p));
      let foundState = '';
      let cityParts = [];
      for (const part of filtered) {
        const code = stateNames[part.toLowerCase()];
        if (code) { foundState = code; } else { cityParts.push(part); }
      }
      const city = cityParts.length > 0 ? properCaseCity(cityParts[cityParts.length - 1]) : '';
      return { city, state: foundState, zip: '' };
    }

    // Handle parenthesized province: "Montreal (QC) H1e7a4" → "Montreal, QC"
    const parenProv = cleaned.match(new RegExp(`^(.+?)\\s*\\(\\s*(${usStates})\\s*\\)(.*)$`, 'i'));
    if (parenProv) {
      const city = parenProv[1].trim();
      const state = parenProv[2].toUpperCase();
      const afterParen = parenProv[3].trim();
      const postalMatch = afterParen.match(new RegExp(`^${caPostalPat}`, 'i'));
      return { city: properCaseCity(city), state, zip: postalMatch ? postalMatch[1].replace(/\s/g, '').toUpperCase() : '' };
    }

    // Handle "Canada (est)" / "Canada," / "Ca," — just country, no useful city data
    if (/^(?:canada|ca)\b/i.test(cleaned.replace(/[,\s()\-]+.*/, ''))) {
      // "Canada, ON" has a real state — let it through to normal parsing
      // "Canada (est)" / "Canada," / "Ca," — nothing useful
      const hasStateCode = cleaned.match(new RegExp(`(?:,|\\s)\\s*(${usStates})\\s*$`, 'i'));
      if (!hasStateCode) {
        return { city: '', state: '', zip: '' };
      }
    }

    // Handle province name/code as entire city: "On," → ON, "New Brunswick," → NB
    const trimmedCleaned = cleaned.replace(/,\s*$/, '').trim();
    if (trimmedCleaned) {
      // Check 2-letter state codes: "On" → ON
      const codeOnly = trimmedCleaned.match(new RegExp(`^(${usStates})$`, 'i'));
      if (codeOnly) return { city: '', state: codeOnly[1].toUpperCase(), zip: '' };
      // Check full province/state names: "New Brunswick" → NB, "Ontaria" (typo, won't match)
      const fullName = stateNames[trimmedCleaned.toLowerCase()];
      if (fullName) return { city: '', state: fullName, zip: '' };
    }

    // Handle strings ending with Canadian postal code: "Ontario N1R 7Z6", "Kingston ON K7M0G5",
    // "232 Hill St S, Thunder Bay, Ontario P7B3V5"
    const provPostal = cleaned.match(new RegExp(`^(.+?)\\s+${caPostalPat}\\s*$`, 'i'));
    if (provPostal) {
      const beforePostal = provPostal[1].trim();
      const zip = provPostal[2].replace(/\s/g, '').toUpperCase();
      // Check if before-postal is just a state/province name or code: "Ontario N1R7Z6"
      const stateCode = stateNames[beforePostal.toLowerCase()];
      if (stateCode) return { city: '', state: stateCode, zip };
      // Check for 2-letter state code at end: "Kingston ON" before postal
      const cityState = beforePostal.match(new RegExp(`^(.+?)\\s+(${usStates})\\s*$`, 'i'));
      if (cityState) {
        const city = stripStreet(cityState[1].trim());
        return { city: properCaseCity(city), state: cityState[2].toUpperCase(), zip };
      }
      // Check for full state name at end: "Thunder Bay, Ontario" or "387 Rexford Drive Hamilton, Ontario"
      for (const [name, code] of Object.entries(stateNames)) {
        if (isCanadian && code === 'CA') continue;
        const re = new RegExp(`^(.+?)[,\\s]+${name}\\s*$`, 'i');
        const nm = beforePostal.match(re);
        if (nm) {
          // Get last meaningful part (after commas) as city, strip any street address
          const parts = nm[1].split(',').map(s => s.trim()).filter(Boolean);
          const rawCity = parts[parts.length - 1];
          const city = stripStreet(rawCity);
          // If stripStreet couldn't clean it (still looks like a street), try to find a known city at the end
          if (isStreetAddress(city) && isCanadian) {
            for (const [cn, cp] of Object.entries(canadianCities)) {
              if (city.toLowerCase().endsWith(' ' + cn)) {
                return { city: properCaseCity(cn), state: code, zip };
              }
            }
            // No known city found — return just state + zip, skip the street
            return { city: '', state: code, zip };
          }
          return { city: properCaseCity(city), state: code, zip };
        }
      }
      // Just "City PostalCode" — try Canadian city lookup
      if (isCanadian && canadianCities[beforePostal.toLowerCase()]) {
        return { city: properCaseCity(beforePostal), state: canadianCities[beforePostal.toLowerCase()], zip };
      }
      return { city: properCaseCity(stripStreet(beforePostal)), state: '', zip };
    }

    // Pre-clean: if first part before comma looks like a street address, drop it
    const commaIdx = cleaned.indexOf(',');
    if (commaIdx >= 0) {
      const beforeFirstComma = cleaned.substring(0, commaIdx).trim();
      if (isStreetAddress(beforeFirstComma) || /^(?:rue|boul\.?|boulevard|ave\.?|avenue|ch\.?|chemin)\s+/i.test(beforeFirstComma)) {
        const afterComma = cleaned.substring(commaIdx + 1).trim();
        if (afterComma) {
          // Just state code after comma: "7470 Boul. Pie-Ix, QC" → QC
          const stateMatch = afterComma.match(new RegExp(`^\\s*(${usStates})\\s*$`, 'i'));
          if (stateMatch) {
            return { city: '', state: stateMatch[1].toUpperCase(), zip: '' };
          }
          // More content after comma — drop the street part, continue parsing the rest
          // "307-45 Twin Oaks Dr Moncton, NB" → "NB" (Moncton is in the street part, lost)
          // But "1078 Main Street North, ON" → "ON" only
          cleaned = afterComma;
        }
      }
    }

    // Pre-clean: whole string is a street address with no comma
    // "157 Legacy Glen Place" / "232 Hill St S" / "9204 102 Ave Sexsmith Ab T0h3c0"
    if (!cleaned.includes(',') && isStreetAddress(cleaned)) {
      // Try to extract a state/province code from anywhere in the string
      const sm = cleaned.match(stateRegex);
      if (sm) {
        return { city: '', state: sm[1].toUpperCase(), zip: '' };
      }
      // Pure street address, nothing extractable
      return { city: '', state: '', zip: '' };
    }

    // Normalize full state names to codes — but ONLY after last comma
    let normalized = cleaned;
    const lastComma = normalized.lastIndexOf(',');
    if (lastComma >= 0) {
      const cityPart = normalized.substring(0, lastComma);
      let statePart = normalized.substring(lastComma);
      for (const [name, code] of Object.entries(stateNames)) {
        if (isCanadian && code === 'CA') continue;
        const re = new RegExp(`\\b${name}\\b`, 'i');
        if (re.test(statePart)) {
          statePart = statePart.replace(re, code);
          break;
        }
      }
      normalized = cityPart + statePart;
    } else {
      // No comma — check for "ST ZIP" (state code + US zip, no city): "SC 29466"
      const stateZipOnly = normalized.match(new RegExp(`^(${usStates})\\s+(\\d{5})\\s*$`, 'i'));
      if (stateZipOnly) {
        return { city: '', state: stateZipOnly[1].toUpperCase(), zip: stateZipOnly[2] };
      }

      // "City ST ZIP" no comma: "Myrtle Beach SC 29466"
      const cityStateZip = normalized.match(new RegExp(`^(.+?)\\s+(${usStates})\\s+(\\d{5})\\s*$`, 'i'));
      if (cityStateZip) {
        const city = stripStreet(cityStateZip[1].trim());
        return { city: properCaseCity(city), state: cityStateZip[2].toUpperCase(), zip: cityStateZip[3] };
      }

      // "City Province" pattern: "Victoria Bc", "Sainte-Barbe Quebec"
      // First try 2-letter code at end: "Victoria BC"
      const codeAtEnd = normalized.match(new RegExp(`^(.+?)\\s+(${usStates})\\s*$`, 'i'));
      if (codeAtEnd) {
        const city = stripStreet(codeAtEnd[1].trim());
        return { city: properCaseCity(city), state: codeAtEnd[2].toUpperCase(), zip: '' };
      }

      // Then try full state/province name at end: "Sainte-Barbe Quebec"
      for (const [name, code] of Object.entries(stateNames)) {
        if (isCanadian && code === 'CA') continue;
        const re = new RegExp(`^(.+?)\\s+${name}\\s*$`, 'i');
        const nm = normalized.match(re);
        if (nm) {
          const city = stripStreet(nm[1].trim());
          return { city: properCaseCity(city), state: code, zip: '' };
        }
      }

      // Try exact match for just a state/province name: "Texas" → "TX", "Ontario" → "ON"
      for (const [name, code] of Object.entries(stateNames)) {
        if (isCanadian && code === 'CA') continue;
        if (new RegExp(`^\\s*${name}\\s*$`, 'i').test(normalized)) {
          return { city: '', state: code, zip: '' };
        }
      }

      // No comma, no state found — try street stripping then Canadian city lookup
      const strippedCity = stripStreet(normalized.trim());
      const cityLower = strippedCity.toLowerCase();
      if (isCanadian && canadianCities[cityLower]) {
        return { city: properCaseCity(strippedCity), state: canadianCities[cityLower], zip: '' };
      }
      // Return as just a city
      return { city: properCaseCity(strippedCity), state: '', zip: '' };
    }

    // Canadian postal code pattern (declared at top of function)

    // Format: "City, ST ZIP" (US 5-digit zip)
    let m = normalized.match(new RegExp(`(.+),\\s*(${usStates})\\s+(\\d{5})`, 'i'));
    if (m) {
      const parts = m[1].split(',').map(s => s.trim());
      const city = stripStreet(parts[parts.length - 1]);
      return { city: properCaseCity(city), state: m[2].toUpperCase(), zip: m[3] };
    }

    // Format: "Street, City ST PostalCode" (Canadian — no comma before province)
    m = normalized.match(new RegExp(`(.+?)\\s+(${usStates})\\s+${caPostalPat}\\s*$`, 'i'));
    if (m) {
      const parts = m[1].split(',').map(s => s.trim());
      const city = stripStreet(parts[parts.length - 1]);
      return { city: properCaseCity(city), state: m[2].toUpperCase(), zip: m[3].replace(/\s/g, '').toUpperCase() };
    }

    // Format: "City, ST PostalCode"
    m = normalized.match(new RegExp(`(.+),\\s*(${usStates})\\s+${caPostalPat}`, 'i'));
    if (m) {
      const parts = m[1].split(',').map(s => s.trim());
      const city = stripStreet(parts[parts.length - 1]);
      return { city: properCaseCity(city), state: m[2].toUpperCase(), zip: m[3].replace(/\s/g, '').toUpperCase() };
    }

    // Format: "City, ST" (no zip)
    m = normalized.match(new RegExp(`(.+),\\s*(${usStates})\\s*$`, 'i'));
    if (m) {
      const parts = m[1].split(',').map(s => s.trim());
      const city = stripStreet(parts[parts.length - 1]);
      return { city: properCaseCity(city), state: m[2].toUpperCase(), zip: '' };
    }

    // "City, COUNTRY_CODE" where country code matched nothing (e.g. "Quebec, CA" for Canadian)
    // Try Canadian city lookup on the city part
    const commaparts = normalized.split(',').map(s => s.trim());
    if (commaparts.length >= 2) {
      const stateMatch = normalized.match(stateRegex);
      if (stateMatch) {
        const city = stripStreet(commaparts[0]);
        return { city: properCaseCity(city), state: stateMatch[1].toUpperCase(), zip: '' };
      }
      // No state found — for Canadian candidates, try city lookup
      if (isCanadian) {
        const cityName = stripStreet(commaparts[0]).toLowerCase();
        if (canadianCities[cityName]) {
          return { city: properCaseCity(commaparts[0]), state: canadianCities[cityName], zip: '' };
        }
      }
      return { city: properCaseCity(stripStreet(commaparts[0])), state: '', zip: '' };
    }

    return { city: properCaseCity(loc.trim()), state: '', zip: '' };
  }

  function sanitizeForFilename(s) {
    // Normalize to ASCII first (accents, smart quotes, dashes), then remove illegal filename chars
    // Also strip commas — they're used as delimiters in the {city,state,zip,email,,phone} metadata block
    return normalizeToASCII(s || '').replace(/[\/\\:*?"<>|{},]/g, '').trim();
  }

  function buildFilename(fullName, serverFilename, contentType, candidateData) {
    // Get file extension
    let ext = '';
    if (serverFilename) {
      const m = serverFilename.match(/\.[a-z0-9]{2,5}$/i);
      if (m) ext = m[0].toLowerCase();
    }
    if (!ext && contentType) {
      const ct = contentType.toLowerCase();
      if (ct.includes('pdf')) ext = '.pdf';
      else if (ct.includes('wordprocessingml')) ext = '.docx';
      else if (ct.includes('msword')) ext = '.doc';
      else if (ct.includes('rtf')) ext = '.rtf';
      else if (ct.includes('text/plain')) ext = '.txt';
    }
    if (!ext) ext = '.pdf';

    // Build name part: lastname_firstname (clean name, then lowercase for system compatibility)
    // First word = first name (used for SMS), everything else = last name
    const nameParts = cleanName(fullName || '').toLowerCase().split(/\s+/).filter(Boolean);
    let namePart = 'unknown_candidate';
    if (nameParts.length >= 2) {
      const first = nameParts[0];
      const last = nameParts.slice(1).join(' ');
      namePart = `${sanitizeForFilename(last)}_${sanitizeForFilename(first)}`;
    } else if (nameParts.length === 1) {
      namePart = sanitizeForFilename(nameParts[0]);
    }

    // Build metadata block: {city,state,zip,email,,phone}
    if (candidateData) {
      const loc = parseLocation(candidateData.location || '', candidateData.country);
      const city = sanitizeForFilename(loc.city);
      const state = sanitizeForFilename(loc.state);
      const zip = sanitizeForFilename(loc.zip);
      const email = sanitizeForFilename((candidateData.email || '').toLowerCase());
      const phone = formatPhone(candidateData.phone || '');
      // reviewtype is always blank (empty between the two commas)
      return `${namePart}{${city},${state},${zip},${email},,${phone}}${ext}`;
    }

    // Fallback if no candidate data: empty metadata block
    return `${namePart}{,,,,,,}${ext}`;
  }

  function parseFilenameFromHeader(header) {
    if (!header) return '';
    let m = header.match(/filename\*=(?:UTF-8''|UTF-8"|utf-8'')([^";\s]+)/i);
    if (m) return decodeURIComponent(m[1].replace(/"/g, ''));
    m = header.match(/filename="([^"]+)"/i);
    if (m) return m[1];
    m = header.match(/filename=([^;\s]+)/i);
    if (m) return m[1];
    return '';
  }

  function formatLocationForCSV(loc, candidateCountry) {
    const parsed = parseLocation(loc, candidateCountry);
    const parts = [];
    if (parsed.city) parts.push(parsed.city);
    if (parsed.state) parts.push(parsed.state);
    if (parsed.zip) parts.push(parsed.zip);
    return parts.length > 0 ? parts.join(', ') : loc || '';
  }

  function formatPhone(ph) {
    if (!ph) return '';
    // Strip country code and non-digits, then format as XXX-XXX-XXXX
    const digits = ph.replace(/\D/g, '').replace(/^1/, ''); // remove +1 or leading 1
    if (digits.length === 10) {
      return `${digits.slice(0,3)}-${digits.slice(3,6)}-${digits.slice(6)}`;
    }
    return digits; // return as-is if not 10 digits
  }

  function escapeCSV(val) {
    if (!val) return '';
    const str = String(val);
    if (str.includes('"') || str.includes(',') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  }

  function generateCSV(rows) {
    const headers = ['Name', 'Email', 'Phone', 'Location', 'Job Title', 'Company', 'Job Location', 'Date Applied', 'Source', 'Resume File', 'Notes'];
    const lines = [headers.map(escapeCSV).join(',')];
    for (const r of rows) {
      lines.push([
        escapeCSV(cleanName(r.name)),                         // Proper case, no credentials/emojis, ASCII
        escapeCSV(normalizeToASCII((r.email || '').toLowerCase())),
        escapeCSV(formatPhone(r.phone)),                       // Normalized XXX-XXX-XXXX
        escapeCSV(normalizeToASCII(formatLocationForCSV(r.location, r.country))),  // Clean "City, ST", ASCII
        escapeCSV(normalizeToASCII(r.jobTitle)),                // Fix smart dashes in job titles
        escapeCSV(normalizeToASCII(r.company)),
        escapeCSV(normalizeToASCII(r.jobLocation)),
        escapeCSV(r.dateApplied),
        escapeCSV(r.source),
        escapeCSV(normalizeToASCII(r.resumeFile)),
        escapeCSV(normalizeToASCII(r.notes))
      ].join(','));
    }
    return lines.join('\n');
  }

  function downloadCSV(csvContent, filename) {
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' }); // BOM for Excel
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 15000);
  }

  // ================================================
  // Cached API key (extracted once, reused)
  // ================================================
  let _indeedApiKey = null;
  function getIndeedApiKey() {
    if (_indeedApiKey) return _indeedApiKey;
    // Search inline scripts for the API key
    for (const s of document.querySelectorAll('script:not([src])')) {
      const txt = s.textContent;
      let m = txt.match(/["']apiKey["']\s*:\s*["']([a-f0-9]{40,})["']/i);
      if (!m) m = txt.match(/api[_-]?key["':\s]+["']([a-f0-9]{40,})["']/i);
      if (m) { _indeedApiKey = m[1]; return _indeedApiKey; }
    }
    // Check window variables
    try {
      const candidates = [
        window.__INDEED_API_KEY__,
        window.__ENV__?.apiKey,
        window.__NEXT_DATA__?.props?.pageProps?.apiKey
      ];
      for (const c of candidates) { if (c) { _indeedApiKey = c; return _indeedApiKey; } }
    } catch (e) {}
    // Check performance entries for API key in URLs
    try {
      for (const e of performance.getEntriesByType('resource')) {
        const m = e.name.match(/[?&]api[_-]?key=([a-f0-9]{40,})/i);
        if (m) { _indeedApiKey = m[1]; return _indeedApiKey; }
      }
    } catch (e) {}
    return null;
  }

  // ================================================
  // GraphQL fetch — uses only Content-Type + Indeed-Api-Key to avoid CORS preflight issues
  // Other Indeed-* headers (Sub-App, Sub-Component, Ctk) trigger CORS blocks
  // ================================================
  async function graphqlFetch(url, payload) {
    const apiKey = getIndeedApiKey();
    const headers = { 'Content-Type': 'application/json' };
    if (apiKey) headers['Indeed-Api-Key'] = apiKey;

    console.log(`[SID] GraphQL call: Indeed-Api-Key=${apiKey ? 'found' : 'MISSING'}`);

    const resp = await fetch(url, {
      method: 'POST',
      credentials: 'include',
      headers: headers,
      body: JSON.stringify(payload)
    });

    const data = await resp.json().catch(() => null);
    return { ok: resp.ok, status: resp.status, data: data };
  }

  // ================================================
  // Mark candidate as reviewed via GraphQL (so they leave the "New" list)
  // ================================================
  async function markAsReviewed(candidateId, csrf) {
    const reactData = getCandidateReactData(candidateId);
    if (!reactData) {
      console.warn(`[SID] Could not get React data for ${candidateId} — skipping mark-as-reviewed`);
      return;
    }

    const payload = {
      operationName: 'UpdateCandidateStatus',
      extensions: {},
      variables: {
        statusInput: {
          move: {
            milestoneId: 'REVIEWED',
            candidateSubmissionEmployerJobIdPairs: [{
              candidateSubmissionId: reactData.candidateSubmissionId,
              jobId: reactData.jobId
            }]
          }
        }
      },
      query: 'mutation UpdateCandidateStatus($statusInput: UpdateCandidateSubmissionMilestoneInput!) {\n  updateCandidateSubmissionMilestone(input: $statusInput) {\n    candidateSubmissionMilestone {\n      category\n      milestoneId\n      __typename\n    }\n    __typename\n  }\n}'
    };

    try {
      const resp = await graphqlFetch('https://apis.indeed.com/graphql?co=US&locale=en-US', payload);
      if (resp.ok && resp.data) {
        const milestone = resp.data?.data?.updateCandidateSubmissionMilestone?.candidateSubmissionMilestone?.milestoneId;
        if (milestone === 'REVIEWED') {
          console.log(`[SID] Marked as reviewed: ${candidateId}`);
        } else {
          console.log(`[SID] Mark-as-reviewed response:`, JSON.stringify(resp.data).substring(0, 200));
        }
      } else {
        console.warn(`[SID] Mark-as-reviewed HTTP ${resp.status} for ${candidateId}`, JSON.stringify(resp.data || resp.error).substring(0, 200));
      }
    } catch (e) {
      console.warn(`[SID] Failed to mark as reviewed: ${candidateId}`, e);
    }
  }

  // Parse a ToUnicode CMap stream into a bidirectional glyph↔unicode mapping
  function parseCMap(cmapText) {
    const toUnicode = new Map();
    const fromUnicode = new Map();

    function addMapping(glyph, ch) {
      toUnicode.set(glyph, ch);
      if (!fromUnicode.has(ch)) fromUnicode.set(ch, glyph);
    }

    // Extract hex values from angle brackets in a string
    function extractHexTokens(str) {
      const tokens = [];
      let i = 0;
      while (i < str.length) {
        const open = str.indexOf('<', i);
        if (open === -1) break;
        const close = str.indexOf('>', open);
        if (close === -1) break;
        tokens.push(str.substring(open + 1, close));
        i = close + 1;
      }
      return tokens;
    }

    const lines = cmapText.split('\n');
    let inBfchar = false, inBfrange = false;

    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.includes('beginbfchar')) { inBfchar = true; continue; }
      if (trimmed.includes('endbfchar'))   { inBfchar = false; continue; }
      if (trimmed.includes('beginbfrange')) { inBfrange = true; continue; }
      if (trimmed.includes('endbfrange'))   { inBfrange = false; continue; }

      if (inBfchar) {
        // Format: <glyphId> <unicode>
        const tokens = extractHexTokens(trimmed);
        if (tokens.length >= 2) {
          const glyph = tokens[0].toUpperCase().padStart(4, '0');
          const ch = String.fromCharCode(parseInt(tokens[1], 16));
          addMapping(glyph, ch);
        }
      } else if (inBfrange) {
        // Format: <start> <end> <unicodeStart>  OR  <start> <end> [<u1> <u2> ...]
        const bracketIdx = trimmed.indexOf('[');
        if (bracketIdx !== -1) {
          // Array form: <start> <end> [<u1> <u2> ...]
          const beforeBracket = trimmed.substring(0, bracketIdx);
          const insideBracket = trimmed.substring(bracketIdx);
          const rangeTokens = extractHexTokens(beforeBracket);
          const arrayTokens = extractHexTokens(insideBracket);
          if (rangeTokens.length >= 2 && arrayTokens.length > 0) {
            const start = parseInt(rangeTokens[0], 16);
            const end = parseInt(rangeTokens[1], 16);
            for (let g = start, i = 0; g <= end && i < arrayTokens.length; g++, i++) {
              const glyph = g.toString(16).toUpperCase().padStart(4, '0');
              const hexVal = arrayTokens[i];
              // Multi-byte unicode values (e.g. <00630074> = "ct" ligature)
              let ch = '';
              for (let j = 0; j < hexVal.length; j += 4) {
                ch += String.fromCharCode(parseInt(hexVal.substring(j, j + 4), 16));
              }
              addMapping(glyph, ch);
            }
          }
        } else {
          // Simple form: <start> <end> <unicodeStart>
          const tokens = extractHexTokens(trimmed);
          if (tokens.length >= 3) {
            const start = parseInt(tokens[0], 16);
            const end = parseInt(tokens[1], 16);
            let uCode = parseInt(tokens[2], 16);
            for (let g = start; g <= end; g++, uCode++) {
              const glyph = g.toString(16).toUpperCase().padStart(4, '0');
              const ch = String.fromCharCode(uCode);
              addMapping(glyph, ch);
            }
          }
        }
      }
    }
    return { toUnicode, fromUnicode };
  }

  // Decode a hex glyph string into Unicode using a CMap
  function decodeHexGlyphs(hexStr, toUnicode) {
    let out = '';
    for (let i = 0; i < hexStr.length; i += 4) {
      out += toUnicode.get(hexStr.substring(i, i + 4).toUpperCase()) || '\uFFFD';
    }
    return out;
  }

  // Encode Unicode text back to hex glyphs; returns null if any char missing from font
  function encodeToHexGlyphs(text, fromUnicode) {
    let hex = '';
    for (const ch of text) {
      const g = fromUnicode.get(ch);
      if (!g) return null;
      hex += g;
    }
    return hex;
  }

  // Replace @indeedemail.com alias with real email inside a PDF blob.
  // Indeed profile resumes use glyph-encoded text (hex IDs mapped via ToUnicode CMap),
  // NOT plain ASCII, so we parse the CMap, decode glyphs, do the swap, re-encode.
  async function replaceIndeedEmail(pdfBlob, realEmail, abortSignal) {
    if (!realEmail || !realEmail.includes('@') || /@indeedemail\.com$/i.test(realEmail)) return pdfBlob;

    try {
      const hasPako = typeof pako !== 'undefined';
      if (!hasPako) console.warn('[SID] pako not loaded — compressed stream replacement disabled');
      const buf = await pdfBlob.arrayBuffer();
      const bytes = new Uint8Array(buf);
      const INDEED_RX = /[a-zA-Z0-9._%+\-]+@indeedemail\.com/g;

      // ---- Use binary regex to reliably find stream boundaries ----
      // (Indeed PDFs use indirect /Length refs like "/Length 49 0 R" which breaks text-based parsing)
      // Convert bytes to a binary string for regex matching.
      // NOTE: Do NOT use TextDecoder('iso-8859-1') — per WHATWG spec it silently uses
      // windows-1252, which remaps bytes 0x80-0x9F to different code points, corrupting
      // compressed stream data when round-tripped via charCodeAt.
      // Chunked String.fromCharCode.apply is byte-accurate and fast (~1ms for 150KB).
      const CHUNK = 8192;
      function bytesToStr(buf) {
        let s = '';
        for (let ci = 0; ci < buf.length; ci += CHUNK) {
          s += String.fromCharCode.apply(null, buf.subarray(ci, Math.min(ci + CHUNK, buf.length)));
        }
        return s;
      }
      let pdf = bytesToStr(bytes);

      // ---- Pass 1: Plain ASCII text (uncompressed annotations, URI actions, metadata) ----
      let changed = false;
      INDEED_RX.lastIndex = 0;
      if (INDEED_RX.test(pdf)) {
        INDEED_RX.lastIndex = 0;
        pdf = pdf.replace(INDEED_RX, realEmail);
        changed = true;
        console.log('[SID] Replaced @indeedemail.com in uncompressed PDF text');
      }

      // ---- Pass 2: Glyph-encoded text in compressed streams ----
      // Quick pre-check: only Indeed profile resumes use CMap-based glyph encoding.
      // They reference /ToUnicode in their font dictionaries.
      // Skip the decompression pass entirely for PDFs without any /ToUnicode reference.
      const hasCMapSignature = pdf.includes('/ToUnicode');

      const cmaps = [];
      const contentStreams = [];

      if (hasCMapSignature && hasPako) {
        // Validate zlib header before attempting DecompressionStream.
        function hasValidZlibHeader(raw) {
          if (raw.length < 2) return false;
          if (raw[0] !== 0x78) return false;
          return (raw[0] * 256 + raw[1]) % 31 === 0;
        }

        // Helper: decompress using pako (pure JS zlib).
        // Chrome's DecompressionStream HANGS on some valid data — reader.cancel() is
        // a no-op and even Promise.race timeouts can't fire if the event loop is blocked.
        // pako.inflate is synchronous: it either works instantly or throws. No hanging.
        function safeDecompress(rawBytes) {
          const decompBytes = pako.inflate(rawBytes);
          if (!decompBytes || !decompBytes.length) throw new Error('inflate returned empty');
          return bytesToStr(decompBytes);
        }

        // Find FlateDecode streams using indexOf (no regex on binary data).
        // The old regex stream(\r?\n)([\s\S]*?)\r?\nendstream caused catastrophic
        // backtracking on some PDFs' binary content, freezing the event loop.
        const streams = []; // { offset, length, dictArea }
        let searchPos = 0;
        while (true) {
          const streamIdx = pdf.indexOf('stream', searchPos);
          if (streamIdx === -1) break;

          // Skip 'endstream' — check that 'stream' is not preceded by 'end'
          if (streamIdx >= 3 && pdf.substring(streamIdx - 3, streamIdx) === 'end') {
            searchPos = streamIdx + 6;
            continue;
          }

          // The 'stream' keyword must be followed by \r\n or \n
          const nextChar = pdf.charCodeAt(streamIdx + 6);
          const nextChar2 = pdf.charCodeAt(streamIdx + 7);
          let dataStart;
          if (nextChar === 0x0D && nextChar2 === 0x0A) {
            dataStart = streamIdx + 8; // stream\r\n
          } else if (nextChar === 0x0A) {
            dataStart = streamIdx + 7; // stream\n
          } else {
            // Not a real stream keyword (e.g. "endstream" or "streamline")
            searchPos = streamIdx + 6;
            continue;
          }

          // Look back for /FlateDecode and /Length in the object dictionary
          const dictStart = Math.max(0, streamIdx - 2000);
          const dictArea = pdf.substring(dictStart, streamIdx);

          if (!dictArea.includes('/FlateDecode')) {
            searchPos = dataStart;
            continue;
          }

          // Get stream length from /Length directive.
          // Matches both direct (/Length 4987) and indirect (/Length 49 0 R) forms.
          // Use the LAST /Length in the lookback area (closest to 'stream' keyword).
          const lengthMatches = [...dictArea.matchAll(/\/Length\s+(\d+)(\s+0\s+R)?/g)];
          const lengthMatch = lengthMatches.length > 0 ? lengthMatches[lengthMatches.length - 1] : null;
          if (!lengthMatch) {
            searchPos = dataStart;
            continue;
          }
          let streamLen;
          if (lengthMatch[2]) {
            // Indirect reference: /Length N 0 R — resolve by finding "N 0 obj\n<value>"
            const objNum = lengthMatch[1];
            const objRx = new RegExp(objNum + '\\s+0\\s+obj[\\s\\S]*?endobj');
            const objMatch = objRx.exec(pdf);
            if (objMatch) {
              const valMatch = objMatch[0].match(/obj\s+(\d+)\s/);
              streamLen = valMatch ? parseInt(valMatch[1]) : null;
            }
            if (!streamLen) {
              console.log(`[SID] Stream skip: could not resolve indirect /Length ${objNum} 0 R`);
              searchPos = dataStart;
              continue;
            }
          } else {
            streamLen = parseInt(lengthMatch[1]);
          }
          if (streamLen <= 0 || dataStart + streamLen > bytes.length) {
            searchPos = dataStart;
            continue;
          }

          // Also find endstream boundary as a safety cap.
          // /Length from a neighboring object in the lookback area could be too long.
          const endTag1 = pdf.indexOf('\nendstream', dataStart);
          const endTag2 = pdf.indexOf('\r\nendstream', dataStart);
          let endstreamPos = -1;
          if (endTag1 !== -1 && endTag2 !== -1) endstreamPos = Math.min(endTag1, endTag2);
          else if (endTag1 !== -1) endstreamPos = endTag1;
          else if (endTag2 !== -1) endstreamPos = endTag2;

          // Cap /Length at the endstream boundary to avoid overrun
          let finalLength = streamLen;
          if (endstreamPos > dataStart && finalLength > endstreamPos - dataStart) {
            finalLength = endstreamPos - dataStart;
          }

          streams.push({ offset: dataStart, length: finalLength, dictArea, streamIdx });
          searchPos = dataStart + finalLength;
        }

        // Phase 1: Find CMaps first (small streams)
        const pendingContentStreams = [];
        for (const s of streams) {
          if (abortSignal && abortSignal.aborted) break;
          const rawBytes = bytes.slice(s.offset, s.offset + s.length);

          if (!hasValidZlibHeader(rawBytes)) continue;

          if (rawBytes.length < 10000) {
            try {
              const text = safeDecompress(rawBytes);
              if (text.includes('beginbfchar') || text.includes('beginbfrange')) {
                cmaps.push(parseCMap(text));
              }
              if (text.includes('BT') && text.includes('ET')) {
                contentStreams.push({ streamInfo: s, text, fmt: 'deflate' });
              }
            } catch (e) {
              // Stream decompression failed — skip silently
            }
          } else {
            pendingContentStreams.push({ streamInfo: s, rawBytes });
          }
        }

        console.log(`[SID] Email scan: ${cmaps.length} CMaps, ${contentStreams.length} content streams, ${pendingContentStreams.length} deferred`);

        // Phase 2: Only decompress large content streams if CMaps were found
        if (cmaps.length > 0 && !(abortSignal && abortSignal.aborted)) {
          for (const pcs of pendingContentStreams) {
            if (abortSignal && abortSignal.aborted) break;
            try {
              const text = safeDecompress(pcs.rawBytes);
              if (text.includes('BT') && text.includes('ET')) {
                contentStreams.push({ streamInfo: pcs.streamInfo, text, fmt: 'deflate' });
              }
            } catch (e) {
              console.log(`[SID] Large stream skip (${pcs.rawBytes.length}B): ${e.message || 'error'}`);
            }
          }
        }
      }

      // Search content streams for glyph-encoded @indeedemail.com
      // Strategy: encode the known target "@indeedemail.com" into each CMap's hex glyphs,
      // then search for that exact hex pattern. This eliminates false positives from wrong CMaps.
      // Check if we can add a fallback font (font dictionary must be in uncompressed PDF)
      const canAddFont = /\/Font\s*<</.test(pdf);
      let needSIDFont = false;

      if (cmaps.length > 0) {
        // Pre-encode the target domain in each CMap's glyph hex
        const targetDomain = '@indeedemail.com';
        const encodedTargets = [];
        for (const cmap of cmaps) {
          const domainHex = encodeToHexGlyphs(targetDomain, cmap.fromUnicode);
          if (domainHex) encodedTargets.push({ cmap, domainHex: domainHex.toUpperCase() });
        }

        for (const cs of contentStreams) {
          const hexRx = /<([0-9A-Fa-f]{4,})>/g;
          const replacements = [];
          const fontSwaps = []; // fallback: swap to Helvetica when glyph encoding fails
          let hm;

          while ((hm = hexRx.exec(cs.text)) !== null) {
            const hexUpper = hm[1].toUpperCase();
            for (const { cmap, domainHex } of encodedTargets) {
              // Look for the exact glyph hex of "@indeedemail.com" inside this hex string
              // Must match on a 4-char glyph boundary (each glyph ID is 4 hex chars)
              let domainPos = hexUpper.indexOf(domainHex);
              while (domainPos !== -1 && domainPos % 4 !== 0) {
                domainPos = hexUpper.indexOf(domainHex, domainPos + 1);
              }
              if (domainPos === -1) continue;

              // Found it — decode the full hex string to get the complete email
              const decoded = decodeHexGlyphs(hm[1], cmap.toUnicode);
              console.log(`[SID] Glyph match candidate — decoded: "${decoded.substring(0, 80)}"`);
              INDEED_RX.lastIndex = 0;
              if (!INDEED_RX.test(decoded)) continue;

              INDEED_RX.lastIndex = 0;
              const replaced = decoded.replace(INDEED_RX, realEmail);
              const newHex = encodeToHexGlyphs(replaced, cmap.fromUnicode);
              if (newHex) {
                replacements.push({ start: hm.index + 1, end: hm.index + 1 + hm[1].length, newHex });
                break;
              }

              // Font-swap fallback: use standard Helvetica for the replacement email
              if (!canAddFont) {
                console.warn('[SID] Font-swap: cannot add font — font dict not in uncompressed PDF for: ' + realEmail);
                break;
              }

              // Find the original font name and size from preceding Tf command
              const textBefore = cs.text.substring(0, hm.index);
              const tfMatches = [...textBefore.matchAll(/\/(\S+)\s+([\d.]+)\s+Tf/g)];
              if (tfMatches.length === 0) {
                console.warn('[SID] Font-swap: no Tf command found before hex string');
                break;
              }
              const origFont = tfMatches[tfMatches.length - 1][1];
              const fontSize = tfMatches[tfMatches.length - 1][2];

              // Find email boundaries in the decoded text (character positions → hex positions)
              INDEED_RX.lastIndex = 0;
              const emailMatch = INDEED_RX.exec(decoded);
              if (!emailMatch) break;
              const emailStartChar = emailMatch.index;
              const emailEndChar = emailMatch.index + emailMatch[0].length;
              const hexBefore = hm[1].substring(0, emailStartChar * 4);
              const hexAfter = hm[1].substring(emailEndChar * 4);

              // Escape PDF string special characters
              const escapedEmail = realEmail.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');

              // Find the Tj/TJ operator after the hex string.
              // Handles both simple "<hex> Tj" and TJ array "[<hex> num ...] TJ" forms.
              const afterHex = cs.text.substring(hm.index + hm[0].length);
              let tjMatch = afterHex.match(/^\s*(Tj)/);  // simple case first
              let isTJArray = false;
              if (!tjMatch) {
                // Check if this hex is inside a TJ array: ...] TJ
                // Look for closing bracket + TJ within next 500 chars
                tjMatch = afterHex.match(/^[^)]*?\]\s*(TJ)/);
                if (tjMatch) isTJArray = true;
              }
              if (!tjMatch) {
                console.warn('[SID] Font-swap: no Tj/TJ operator found after hex string, next 60 chars: ' + JSON.stringify(afterHex.substring(0, 60)));
                break;
              }

              // For TJ arrays, we need to replace the entire array entry.
              // Find the opening bracket before our hex string.
              let origOp, origOpEnd;
              if (isTJArray) {
                // Search backwards from hm.index to find the [ that opens this TJ array
                const before = cs.text.substring(Math.max(0, hm.index - 500), hm.index);
                const bracketPos = before.lastIndexOf('[');
                if (bracketPos === -1) {
                  console.warn('[SID] Font-swap: TJ array but no opening bracket found');
                  break;
                }
                const arrayStart = Math.max(0, hm.index - 500) + bracketPos;
                origOpEnd = hm.index + hm[0].length + tjMatch.index + tjMatch[0].length;
                origOp = cs.text.substring(arrayStart, origOpEnd);
              } else {
                origOpEnd = hm.index + hm[0].length + tjMatch.index + tjMatch[0].length;
                origOp = cs.text.substring(hm.index, origOpEnd);
              }

              // Build replacement: hex_before + font switch + ASCII email + font switch back + hex_after
              let newOp = '';
              if (hexBefore.length > 0) newOp += `<${hexBefore}> Tj `;
              newOp += `/SIDHelv ${fontSize} Tf (${escapedEmail}) Tj`;
              if (hexAfter.length > 0) newOp += ` /${origFont} ${fontSize} Tf <${hexAfter}> Tj`;

              fontSwaps.push({ original: origOp, replacement: newOp });
              needSIDFont = true;
              console.log(`[SID] Using Helvetica font-swap for email replacement: ${realEmail}`);
              break;
            }
          }

          if (replacements.length === 0 && fontSwaps.length === 0) continue;

          // Apply hex replacements within this stream's decompressed text
          let newText = cs.text;
          replacements.sort((a, b) => b.start - a.start);
          for (const rep of replacements) {
            newText = newText.substring(0, rep.start) + rep.newHex + newText.substring(rep.end);
          }
          // Apply font-swap replacements (Helvetica fallback)
          for (const fs of fontSwaps) {
            newText = newText.split(fs.original).join(fs.replacement);
          }

          // Recompress the modified stream
          const newDecompBytes = new Uint8Array(newText.length);
          for (let j = 0; j < newText.length; j++) newDecompBytes[j] = newText.charCodeAt(j);

          const newCompBytes = pako.deflate(newDecompBytes);

          const newCompStr = bytesToStr(newCompBytes);

          // Replace stream data in the PDF string
          const streamDataStart = cs.streamInfo.offset;
          const streamDataEnd = streamDataStart + cs.streamInfo.length;
          pdf = pdf.substring(0, streamDataStart) + newCompStr + pdf.substring(streamDataEnd);

          // Update /Length — handle both indirect (N 0 R) and direct values
          const dictEnd = cs.streamInfo.streamIdx; // position of "stream"
          const dictStart = Math.max(0, dictEnd - 2000);
          const dictArea = pdf.substring(dictStart, dictEnd);

          // Try indirect /Length N 0 R first
          const indirectRx = /\/Length\s+(\d+)\s+0\s+R/g;
          const indirectMatches = [...dictArea.matchAll(indirectRx)];
          if (indirectMatches.length > 0) {
            const lastMatch = indirectMatches[indirectMatches.length - 1];
            const objNum = lastMatch[1];
            // Find the referenced object and update its value
            const objRx = new RegExp(objNum + '\\s+0\\s+obj\\s*\\n(\\d+)\\s*\\nendobj');
            const objMatch = objRx.exec(pdf);
            if (objMatch) {
              pdf = pdf.substring(0, objMatch.index + objMatch[0].indexOf(objMatch[1]))
                + String(newCompBytes.length)
                + pdf.substring(objMatch.index + objMatch[0].indexOf(objMatch[1]) + objMatch[1].length);
            }
          } else {
            // Direct /Length N
            const directRx = /\/Length\s+(\d+)/g;
            const directMatches = [...dictArea.matchAll(directRx)];
            if (directMatches.length > 0) {
              const lastMatch = directMatches[directMatches.length - 1];
              const absPos = dictStart + lastMatch.index;
              pdf = pdf.substring(0, absPos) + `/Length ${newCompBytes.length}` + pdf.substring(absPos + lastMatch[0].length);
            }
          }

          changed = true;
          console.log(`[SID] Replaced @indeedemail.com in glyph-encoded PDF stream`);
        }
      }

      // ---- Pass 3: Plain ASCII in compressed streams (fallback for non-glyph PDFs) ----
      if (!changed) {
        for (const cs of contentStreams) {
          INDEED_RX.lastIndex = 0;
          if (!INDEED_RX.test(cs.text)) continue;

          INDEED_RX.lastIndex = 0;
          const newText = cs.text.replace(INDEED_RX, realEmail);

          const newDecompBytes = new Uint8Array(newText.length);
          for (let j = 0; j < newText.length; j++) newDecompBytes[j] = newText.charCodeAt(j);

          const newCompBytes = pako.deflate(newDecompBytes);

          const newCompStr = bytesToStr(newCompBytes);

          const streamDataStart = cs.streamInfo.offset;
          const streamDataEnd = streamDataStart + cs.streamInfo.length;
          pdf = pdf.substring(0, streamDataStart) + newCompStr + pdf.substring(streamDataEnd);

          changed = true;
          console.log('[SID] Replaced @indeedemail.com in compressed ASCII stream');
        }
      }

      if (!changed) return pdfBlob;

      // Add Helvetica font to PDF if font-swap was used
      if (needSIDFont) {
        // Find the highest object number to assign a new one
        const objNums = [...pdf.matchAll(/(\d+)\s+0\s+obj/g)].map(m => parseInt(m[1]));
        const newObjNum = Math.max(...objNums) + 1;

        // Create Helvetica font object
        const fontObj = `\n${newObjNum} 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj\n`;

        // Add font reference to the page's font dictionary: /Font << ... /SIDHelv N 0 R >>
        const fontDictRx = /(\/Font\s*<<)([^]*?)(>>)/;
        const fdm = fontDictRx.exec(pdf);
        if (fdm) {
          const insertRef = ` /SIDHelv ${newObjNum} 0 R `;
          pdf = pdf.substring(0, fdm.index + fdm[1].length) + fdm[2] + insertRef + pdf.substring(fdm.index + fdm[0].length - fdm[3].length);

          // Append font object at the end of the body (before xref)
          let insertPos = pdf.lastIndexOf('\nxref');
          if (insertPos === -1) insertPos = pdf.lastIndexOf('\rxref');
          if (insertPos > 0) {
            pdf = pdf.substring(0, insertPos) + fontObj + pdf.substring(insertPos);
          } else {
            // No xref found — just append before %%EOF
            const eofPos = pdf.lastIndexOf('%%EOF');
            if (eofPos > 0) pdf = pdf.substring(0, eofPos) + fontObj + pdf.substring(eofPos);
          }
          console.log('[SID] Added Helvetica (SIDHelv) font to PDF for email replacement');
        } else {
          console.warn('[SID] Could not locate font dictionary — Helvetica fallback incomplete');
        }
      }

      // Rebuild cross-reference table to fix byte offsets after modifications
      const tMatch = pdf.match(/trailer\s*<<([\s\S]*?)>>/);
      let tDict = tMatch ? tMatch[1] : '';
      let cut = pdf.lastIndexOf('\nxref');
      if (cut === -1) cut = pdf.lastIndexOf('\rxref');
      if (cut > 0) {
        pdf = pdf.substring(0, cut + 1);
        const objRx = /(?:^|\r?\n)(\d+)\s+(\d+)\s+obj\b/gm;
        const objs = new Map();
        let maxN = 0, om;
        while ((om = objRx.exec(pdf)) !== null) {
          const n = parseInt(om[1]);
          const off = om.index + (om[0].length - om[0].trimStart().length);
          objs.set(n, { off, gen: parseInt(om[2]) });
          if (n > maxN) maxN = n;
        }
        const xrefOff = pdf.length;
        let xr = 'xref\n0 ' + (maxN + 1) + '\n';
        xr += '0000000000 65535 f \r\n';
        for (let i = 1; i <= maxN; i++) {
          const e = objs.get(i);
          if (e) xr += String(e.off).padStart(10, '0') + ' ' + String(e.gen).padStart(5, '0') + ' n \r\n';
          else xr += '0000000000 00000 f \r\n';
        }
        if (tDict) {
          tDict = tDict.replace(/\/Size\s+\d+/, `/Size ${maxN + 1}`);
          if (!/\/Size/.test(tDict)) tDict += ` /Size ${maxN + 1}`;
        } else {
          const rootM = pdf.match(/\/Root\s+\d+\s+\d+\s+R/);
          tDict = ` /Size ${maxN + 1}` + (rootM ? ` ${rootM[0]}` : '');
        }
        xr += `trailer\n<<${tDict}>>\nstartxref\n${xrefOff}\n%%EOF`;
        pdf += xr;
      }

      const out = new Uint8Array(pdf.length);
      for (let i = 0; i < pdf.length; i++) out[i] = pdf.charCodeAt(i);
      return new Blob([out], { type: 'application/pdf' });

    } catch (e) {
      console.warn('[SID] replaceIndeedEmail failed:', e.message);
      return pdfBlob; // Return original on any error
    }
  }

  // ================================================
  // Direct API download for one candidate — store in IndexedDB
  // ================================================
  function withTimeout(promise, ms, label) {
    return Promise.race([
      promise,
      new Promise((_, reject) => setTimeout(() => reject(new Error(`Timeout: ${label} took >${ms / 1000}s`)), ms))
    ]);
  }

  async function downloadResume(candidateId, candidateName, csrf, candidateData) {
    const url = `https://employers.indeed.com/api/catws/resume/v2/download?id=${candidateId}&indeedcsrftoken=${csrf}`;
    try {
      const resp = await withTimeout(
        fetch(url, {
          method: 'GET',
          credentials: 'include',
          headers: { 'Accept': 'application/pdf,application/octet-stream,*/*' }
        }),
        30000, `fetch ${candidateName}`
      );
      if (!resp.ok) {
        console.warn(`[SID] HTTP ${resp.status} for ${candidateName} (${candidateId})`);
        return resp.status === 404 ? 'no_resume' : 'error';
      }
      const contentType = resp.headers.get('content-type') || '';
      const disposition = resp.headers.get('content-disposition') || '';
      const serverName  = parseFilenameFromHeader(disposition);
      if (contentType.startsWith('text/html')) {
        console.warn(`[SID] HTML response for ${candidateName} — no resume?`);
        return 'no_resume';
      }
      const blob = await withTimeout(resp.blob(), 30000, `blob ${candidateName}`);
      if (blob.size < 500) {
        console.warn(`[SID] Tiny response (${blob.size}B) for ${candidateName}`);
        return 'no_resume';
      }
      const filename = buildFilename(candidateName, serverName, contentType, candidateData);

      // Replace @indeedemail.com alias with real email in Indeed profile resumes
      const realEmail = (candidateData?.email || '').trim().toLowerCase();
      let finalBlob;
      const emailAbort = new AbortController();
      try {
        finalBlob = await withTimeout(replaceIndeedEmail(blob, realEmail, emailAbort.signal), 5000, `email replace ${candidateName}`);
      } catch (emailErr) {
        emailAbort.abort(); // stop background processing immediately
        console.warn(`[SID] Email replacement timed out for ${candidateName}, using original PDF`);
        finalBlob = blob; // safe fallback — use original PDF
      }

      // Store in IndexedDB instead of downloading immediately
      const legacyId = candidateData?.legacyId || candidateId;
      await storeResume(KEY, candidateId, filename, finalBlob, legacyId);
      console.log(`[SID] Stored: ${filename} (${(finalBlob.size / 1024).toFixed(0)} KB) [legacyId=${legacyId}]`);

      return { status: 'ok', filename: filename };
    } catch (e) {
      console.error(`[SID] Fetch error for ${candidateName}:`, e);
      return 'error';
    }
  }

  // ================================================
  // Generate and download zip file
  // ================================================
  async function generateAndDownloadZip(jobTitle, csvContent, jobKey) {
    setStatus('Building zip — loading resumes...');

    try {
      const zip = new JSZip();

      // Get resumes for this job from IndexedDB
      const resumes = await getResumesForJob(jobKey || KEY);

      // Create a folder named after the job title
      const folderName = normalizeToASCII(jobTitle).replace(/[^a-zA-Z0-9 \-]/g, '').replace(/\s+/g, '_') || 'Resumes';
      const folder = zip.folder(folderName);

      // Add all resumes to the folder, showing progress
      for (let i = 0; i < resumes.length; i++) {
        folder.file(resumes[i].filename, resumes[i].blob);
        if (i % 50 === 0 || i === resumes.length - 1) {
          setStatus(`Packing file ${i + 1} of ${resumes.length}...`);
        }
      }

      // Add CSV at root level
      const csvBlob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
      const dateStr = toEasternDateStr();
      const jobFileName = (jobTitle || 'candidates').replace(/[^a-zA-Z0-9 ]/g, '').replace(/\s+/g, '_');
      const csvFilename = `SID_${jobFileName}_${dateStr}.csv`;
      zip.file(csvFilename, csvBlob);

      // Generate zip with progress
      setStatus(`Compressing ${resumes.length} files...`);
      const zipBlob = await zip.generateAsync(
        { type: 'blob' },
        (meta) => {
          if (meta.percent) {
            setStatus(`Compressing... ${Math.round(meta.percent)}%`);
          }
        }
      );
      const zipFilename = `SID_${jobFileName}_${dateStr}.zip`;
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = zipFilename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 15000);

      const sizeMB = (zipBlob.size / 1024 / 1024).toFixed(1);
      setStatus(`Done! ${zipFilename} (${sizeMB} MB)`);
      console.log(`[SID] Generated zip: ${zipFilename} (${sizeMB} MB, ${resumes.length} resumes)`);
    } catch (e) {
      console.error('[SID] Zip generation failed:', e);
      setStatus('Zip generation failed — check console');
    }
  }

  // Generate a single zip containing ALL jobs as subfolders
  async function generateAllJobsZip() {
    setStatus('Building combined zip — gathering all jobs...');

    try {
      // Collect today's resumes by per-resume timestamp (not job-level savedDate)
      const today = toEasternDateStr();
      const allResumesRaw = await getAllResumes();
      const allResumes = allResumesRaw.filter(r => r.timestamp && toEasternDateStr(r.timestamp) === today);

      if (allResumes.length === 0) {
        setStatus('No resumes from today to download');
        return;
      }

      // Collect CSV data for jobs that have today's resumes,
      // FILTER each job's CSV rows to today's candidates, and DEDUPE within
      // each per-job CSV by legacyId / email+phone / filename so jobKey conflation
      // (same Indeed posting absorbing rows from a sibling posting) doesn't surface
      // as duplicate rows in the per-job output.
      const todayJobKeys = new Set(allResumes.map(r => r.jobKey));
      const todayLegacyIds = new Set(allResumes.map(r => r.legacyId).filter(Boolean));
      const todayFilenames = new Set(allResumes.map(r => r.filename).filter(Boolean));
      const allCsvData = await getAllCSV();
      const jobs = [];
      for (const csvEntry of allCsvData) {
        const allRows = csvEntry.rows || [];
        if (allRows.length === 0) continue;
        if (!todayJobKeys.has(csvEntry.jobKey)) continue;
        // Step 1: filter to today's candidates only
        const filteredRows = allRows.filter(row =>
          (row && row.legacyId && todayLegacyIds.has(row.legacyId)) ||
          (row && row.resumeFile && todayFilenames.has(row.resumeFile))
        );
        if (filteredRows.length === 0) continue;
        // Step 2: dedup within this job. Same person should appear at most once
        // per per-job CSV, even if they have multiple application records.
        const seenIds = new Set();
        const seenEmailPhone = new Set();
        const seenFilenames = new Set();
        const csv = [];
        let jobDupesSkipped = 0;
        for (const row of filteredRows) {
          if (!row) continue;
          // Dedup #1: by legacyId (Indeed's per-submission ID)
          if (row.legacyId && seenIds.has(row.legacyId)) { jobDupesSkipped++; continue; }
          // Dedup #2: by email + phone (catches same person with different legacyIds
          // across cross-promoted/cloned postings absorbed into one jobKey)
          const ep = `${(row.email || '').toLowerCase()}|${row.phone || ''}`;
          if (ep !== '|' && seenEmailPhone.has(ep)) { jobDupesSkipped++; continue; }
          // Dedup #3: by resume filename (last-resort catch — same name+contact info)
          if (row.resumeFile && seenFilenames.has(row.resumeFile)) { jobDupesSkipped++; continue; }
          if (row.legacyId) seenIds.add(row.legacyId);
          if (ep !== '|') seenEmailPhone.add(ep);
          if (row.resumeFile) seenFilenames.add(row.resumeFile);
          csv.push(row);
        }
        if (jobDupesSkipped > 0) {
          console.log(`[SID] Per-job CSV dedup: ${jobDupesSkipped} duplicate row(s) removed from ${csvEntry.jobKey}`);
        }
        if (csv.length === 0) continue;
        jobs.push({ key: csvEntry.jobKey, csv });
      }
      // Index by jobKey for fast lookup
      const resumesByJob = {};
      for (const r of allResumes) {
        if (!resumesByJob[r.jobKey]) resumesByJob[r.jobKey] = [];
        resumesByJob[r.jobKey].push(r);
      }

      const zip = new JSZip();
      let totalFiles = 0;
      let dupeSkipped = 0;
      const dateStr = toEasternDateStr();
      const usedFilenames = new Set();
      const seenCandidates = new Set(); // dedup same candidate across multiple job postings

      // Two subfolders: Resumes (all PDFs flat) and CSV (per-job CSVs)
      const resumesFolder = zip.folder('Resumes');
      const csvFolder = zip.folder('CSV');

      // Pre-extract email+phone from filename pattern: name{location,...,email,...,phone}.ext
      // Lets us dedup people whose Indeed per-submission legacyIds differ across cross-
      // promoted postings but whose contact info is identical.
      const seenEmailPhone = new Set();
      function extractEmailPhone(filename) {
        const m = (filename || '').match(/\{([^}]*)\}/);
        if (!m) return '';
        const parts = m[1].split(',');
        // Pattern: {city,state,zip,email,?,phone}
        const email = (parts[3] || '').trim().toLowerCase();
        const phone = (parts[5] || parts[4] || '').trim();
        if (!email && !phone) return '';
        return `${email}|${phone}`;
      }

      for (const r of allResumes) {
        // Skip duplicate candidates (same person applied to multiple postings)
        // Layer 1: dedup by legacyId
        const dedupKey = r.legacyId || r.candidateId;
        if (dedupKey && seenCandidates.has(dedupKey)) {
          dupeSkipped++;
          continue;
        }
        // Layer 2: dedup by filename (same name+contact info → same file)
        if (usedFilenames.has(r.filename)) {
          dupeSkipped++;
          continue;
        }
        // Layer 3: dedup by email+phone parsed from filename (catches cases where
        // Indeed gave the same person different legacyIds across applications AND
        // somehow the filenames differ by stray whitespace/casing)
        const ep = extractEmailPhone(r.filename);
        if (ep && seenEmailPhone.has(ep)) {
          dupeSkipped++;
          continue;
        }
        if (dedupKey) seenCandidates.add(dedupKey);
        if (ep) seenEmailPhone.add(ep);

        let fname = r.filename;
        usedFilenames.add(fname);
        resumesFolder.file(fname, r.blob);
        totalFiles++;
        if (totalFiles % 100 === 0) {
          setStatus(`Packed ${totalFiles} resumes...`);
        }
      }

      // Per-job CSVs in the CSV folder
      for (const job of jobs) {
        const jobTitle = job.csv[0]?.jobTitle || 'Unknown_Job';
        const csvContent = generateCSV(job.csv);
        const csvBlob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
        const jobFileName = (jobTitle).replace(/[^a-zA-Z0-9 ]/g, '').replace(/\s+/g, '_');
        csvFolder.file(`SID_${jobFileName}_${dateStr}.csv`, csvBlob);
      }

      // Candidate Master CSV — one row per unique candidate with all jobs they applied to.
      // Keyed by email+phone first (catches same person with different per-submission
      // legacyIds), with legacyId then name as fallbacks for incomplete data.
      const candidateMap = new Map();
      for (const job of jobs) {
        for (const row of job.csv) {
          const ep = `${(row.email || '').toLowerCase()}|${row.phone || ''}`;
          const cid = (ep !== '|') ? ep : (row.legacyId || row.name || '');
          if (!cid) continue;
          if (!candidateMap.has(cid)) {
            candidateMap.set(cid, {
              name: row.name || '',
              email: row.email || '',
              phone: row.phone || '',
              location: row.location || '',
              country: row.country || '',
              resumeFile: row.resumeFile || '',
              appliedTo: []
            });
          }
          const entry = candidateMap.get(cid);
          // Add this job title if not already listed
          const jt = row.jobTitle || 'Unknown';
          if (!entry.appliedTo.includes(jt)) entry.appliedTo.push(jt);
          // Fill in any missing info from later job rows
          if (!entry.email && row.email) entry.email = row.email;
          if (!entry.phone && row.phone) entry.phone = row.phone;
          if (!entry.resumeFile && row.resumeFile) entry.resumeFile = row.resumeFile;
        }
      }
      // Build the master CSV
      const masterHeaders = ['Name', 'Email', 'Phone', 'Location', 'Resume File', 'Applied To', 'Number of Applications'];
      const masterLines = [masterHeaders.map(escapeCSV).join(',')];
      for (const [, c] of candidateMap) {
        masterLines.push([
          escapeCSV(cleanName(c.name)),
          escapeCSV(normalizeToASCII((c.email || '').toLowerCase())),
          escapeCSV(formatPhone(c.phone)),
          escapeCSV(normalizeToASCII(formatLocationForCSV(c.location, c.country))),
          escapeCSV(normalizeToASCII(c.resumeFile)),
          escapeCSV(c.appliedTo.join(' | ')),
          escapeCSV(String(c.appliedTo.length))
        ].join(','));
      }
      const masterCsvContent = masterLines.join('\n');
      const masterBlob = new Blob(['\uFEFF' + masterCsvContent], { type: 'text/csv;charset=utf-8;' });
      csvFolder.file(`SID_Candidate_Master_${dateStr}.csv`, masterBlob);

      if (totalFiles === 0) {
        setStatus('No resume files found in storage');
        return;
      }

      setStatus(`Compressing ${totalFiles} files from ${jobs.length} jobs...`);
      const zipBlob = await zip.generateAsync(
        { type: 'blob' },
        (meta) => {
          if (meta.percent) {
            setStatus(`Compressing all jobs... ${Math.round(meta.percent)}%`);
          }
        }
      );

      const zipFilename = `SID_All_Jobs_${dateStr}.zip`;
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = zipFilename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 15000);

      const sizeMB = (zipBlob.size / 1024 / 1024).toFixed(1);
      const dupeNote = dupeSkipped > 0 ? ` · ${dupeSkipped} duplicate${dupeSkipped === 1 ? '' : 's'} removed` : '';
      setStatus(`Done! ${zipFilename} (${sizeMB} MB, ${totalFiles} resumes, ${jobs.length} job${jobs.length === 1 ? '' : 's'}${dupeNote})`);
      console.log(`[SID] Generated combined zip: ${zipFilename} (${sizeMB} MB, ${totalFiles} resumes, ${jobs.length} jobs, ${dupeSkipped} duplicates removed)`);
    } catch (e) {
      console.error('[SID] Combined zip generation failed:', e);
      setStatus('Combined zip failed — check console');
    }
  }

  // ================================================
  // UI — SID Widget (PASTEL THEME)
  // ================================================
  let running = false;
  let collapsed = false;
  let box, headerBar, bodyWrap;
  let controlBtn, statusEl, statusFreshLink, progressBarFill, progressText;
  let statProcessed, statSkip, statTimeLeft;
  let skippedPanel, skippedPanelList;
  let historyPanel, historyPanelList;
  let downloadZipBtn;
  let updateDownloadAllBtn = () => {}; // hoisted — assigned inside buildWidget
  let csvRows = [];
  let _initLoaded = false; // true once IndexedDB state has been loaded
  // Load ALL state from IndexedDB (done, skip, csv) — then update widget
  (async function initLoadState() {
    let data = await loadJobData(KEY);
    // If no data found, try migrating from an old unstable key
    if (!data || (!data.done?.length && !data.skip?.length)) {
      data = await _findAndMigrateOldData(KEY);
    }
    if (data) {
      if (data.done && data.done.length > 0) downloaded = new Set(data.done);
      if (data.skip && data.skip.length > 0) skipped = new Set(data.skip);
      if (data.rows && data.rows.length > 0) csvRows = data.rows;
      console.log(`[SID] INIT loaded from IndexedDB: ${downloaded.size} done, ${skipped.size} skipped, ${csvRows.length} csv`);
    } else {
      console.log(`[SID] INIT: no saved data for KEY="${KEY}"`);
    }
    _initLoaded = true;
    // Update widget with loaded state
    if (typeof updateStats === 'function') updateStats();
    if (typeof showIdleState === 'function') showIdleState();
    if (typeof updateDownloadAllBtn === 'function') updateDownloadAllBtn();
    if (downloadZipBtn && csvRows.length > 0) downloadZipBtn.style.display = 'block';
  })();

  // Tracking for ETA
  let startTime = 0;
  let dlCount = 0;

  // New-only run baseline — subtracted from stats display
  let _statsBaselineDownloaded = 0;
  let _statsBaselineSkipped = 0;

  // Skip tracking
  let skippedDetails = []; // array of { id, name, reason, detail }

  const CSS = {
    headerGrad: 'linear-gradient(135deg, #c4b5e3 0%, #d8c8f0 50%, #e0d0f5 100%)',
    bg: '#f0ecf6',
    bgCard: '#faf8fd',
    bgCardBorder: '#ddd8ec',
    bgHover: '#f0ecf6',
    text: '#3d3450',
    textDim: '#7a7094',
    textMedium: '#6b6180',
    mint: '#5cb88a',
    mintLight: '#b8e6d0',
    mintDark: '#2d5c42',
    mintGrad: 'linear-gradient(135deg, #b8e6d0, #98d4b8)',
    peach: '#d08060',
    peachLight: '#f5cfc0',
    peachDark: '#7a3d2d',
    peachGrad: 'linear-gradient(135deg, #f5cfc0, #edb5a0)',
    lav: '#7860a8',
    lavLight: '#c4b5e3',
    lavGrad: 'linear-gradient(135deg, #b8a8d8, #c8b8e8)',
    divider: '#ddd8ec',
    progressBg: '#ddd8ec',
    progressFill: 'linear-gradient(90deg, #b8a8d8, #c8b8e8)',
    progressDone: 'linear-gradient(90deg, #b8e6d0, #98d4b8)',
    shadow: '0 4px 20px rgba(80,60,120,0.20), 0 12px 40px rgba(100,80,140,0.12), 0 0 0 1px rgba(150,130,190,0.30)',
    radius: '16px',
    radiusSm: '10px',
    radiusXs: '8px',
    font: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
  };

  function el(tag, styles, text) {
    const e = document.createElement(tag);
    if (styles) Object.assign(e.style, styles);
    if (text) e.textContent = text;
    return e;
  }

  function createUI() {
    // --- Inject keyframes ---
    const style = document.createElement('style');
    style.textContent = `
      @keyframes sid-pulse { 0%,100%{opacity:1} 50%{opacity:.6} }
      @keyframes sid-slide { from{transform:translateY(-4px);opacity:0} to{transform:translateY(0);opacity:1} }
      @keyframes sid-shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
      .sid-btn:hover { filter: brightness(0.95); }
      .sid-btn:active { transform: scale(0.97); }
      .sid-item { animation: sid-slide 0.2s ease-out; }
    `;
    document.head.appendChild(style);

    // --- Main container ---
    box = el('div', {
      position: 'fixed', top: '80px', right: '16px',
      background: CSS.bg, color: CSS.text,
      borderRadius: CSS.radius, zIndex: '99999',
      fontFamily: CSS.font, fontSize: '13px',
      userSelect: 'none', width: '280px',
      boxShadow: CSS.shadow,
      border: `1px solid ${CSS.bgCardBorder}`,
      overflow: 'hidden',
      transition: 'width 0.3s ease, height 0.3s ease'
    });

    // --- Header bar (lavender gradient, always visible) ---
    headerBar = el('div', {
      background: CSS.headerGrad,
      padding: '12px 16px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      cursor: 'move', gap: '8px'
    });

    const titleArea = el('div', { display: 'flex', alignItems: 'center', gap: '10px' });

    // SID logo — cartoon sloth face
    const logo = document.createElement('div');
    logo.innerHTML = `<svg width="36" height="36" viewBox="0 0 100 100">
      <!-- Hair tufts -->
      <path d="M38 12 Q36 2 32 5 Q34 10 38 14Z" fill="#7a5c3a"/>
      <path d="M50 8 Q50 -2 46 2 Q48 7 50 12Z" fill="#7a5c3a"/>
      <path d="M62 12 Q64 2 68 5 Q66 10 62 14Z" fill="#7a5c3a"/>
      <!-- Head shape -->
      <ellipse cx="50" cy="52" rx="38" ry="40" fill="#d4a96a"/>
      <!-- Lighter face patch -->
      <ellipse cx="50" cy="58" rx="28" ry="28" fill="#e8c88a"/>
      <!-- Left eye white -->
      <ellipse cx="38" cy="46" rx="10" ry="11" fill="white"/>
      <!-- Right eye white -->
      <ellipse cx="62" cy="46" rx="10" ry="11" fill="white"/>
      <!-- Left iris -->
      <circle cx="39" cy="46" r="6" fill="#3b8ed0"/>
      <!-- Right iris -->
      <circle cx="63" cy="46" r="6" fill="#3b8ed0"/>
      <!-- Left pupil -->
      <circle cx="40" cy="45" r="3" fill="#1a1a2e"/>
      <!-- Right pupil -->
      <circle cx="64" cy="45" r="3" fill="#1a1a2e"/>
      <!-- Eye shine -->
      <circle cx="41" cy="43" r="1.5" fill="white"/>
      <circle cx="65" cy="43" r="1.5" fill="white"/>
      <!-- Nose -->
      <ellipse cx="50" cy="60" rx="8" ry="6" fill="#8b6baa"/>
      <!-- Nose highlight -->
      <ellipse cx="48" cy="58" rx="3" ry="2" fill="#a080c0" opacity="0.5"/>
      <!-- Mouth -->
      <path d="M43 68 Q50 76 57 68" stroke="#7a5c3a" stroke-width="2" fill="none" stroke-linecap="round"/>
      <!-- Ears -->
      <ellipse cx="18" cy="38" rx="8" ry="10" fill="#d4a96a"/>
      <ellipse cx="18" cy="38" rx="5" ry="7" fill="#e8c88a"/>
      <ellipse cx="82" cy="38" rx="8" ry="10" fill="#d4a96a"/>
      <ellipse cx="82" cy="38" rx="5" ry="7" fill="#e8c88a"/>
    </svg>`;
    logo.style.lineHeight = '0';

    const titleText = el('div', {});
    titleText.innerHTML = '<div style="font-weight:700;font-size:15px;letter-spacing:0.5px;color:#3d3450">SID</div><div style="font-size:10px;opacity:0.8;margin-top:1px;color:#5d5070">Smart Indeed Downloader</div>';

    titleArea.append(logo, titleText);

    // Collapse button — translucent white with dark text
    const collapseBtn = el('button', {
      background: 'rgba(255,255,255,0.5)', border: 'none', color: '#3d3450',
      width: '26px', height: '26px', borderRadius: '6px',
      cursor: 'pointer', fontSize: '14px', display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      transition: 'background 0.2s', padding: '0', lineHeight: '1'
    }, '–');
    collapseBtn.className = 'sid-btn';
    collapseBtn.title = 'Minimize';
    collapseBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      collapsed = !collapsed;
      bodyWrap.style.display = collapsed ? 'none' : 'block';
      collapseBtn.textContent = collapsed ? '+' : '–';
      collapseBtn.title = collapsed ? 'Expand' : 'Minimize';
    });

    headerBar.append(titleArea, collapseBtn);

    // --- Body ---
    bodyWrap = el('div', { padding: '14px 16px' });

    // Control button — mint gradient for Start, peach for Stop
    controlBtn = el('button', {
      width: '100%', padding: '10px 0', border: 'none',
      borderRadius: CSS.radiusSm, color: '#fff',
      fontSize: '14px', fontWeight: '700', cursor: 'pointer',
      background: CSS.mintGrad, letterSpacing: '0.3px',
      transition: 'all 0.15s ease'
    }, 'Start');
    controlBtn.className = 'sid-btn';

    // Status text
    statusEl = el('div', {
      textAlign: 'center', fontSize: '12px', color: '#5d5478',
      marginTop: '10px', minHeight: '16px',
      wordWrap: 'break-word', overflowWrap: 'break-word', whiteSpace: 'normal'
    }, 'Ready');

    // "start fresh" link — shown under status when job has existing history
    statusFreshLink = el('div', {
      textAlign: 'center', marginTop: '4px', display: 'none'
    });
    const freshLink = el('span', {
      fontSize: '10px', color: CSS.lav, cursor: 'pointer',
      borderBottom: `1px dotted ${CSS.lav}`, transition: 'color 0.15s'
    }, 'redo all');
    freshLink.addEventListener('mouseenter', () => { freshLink.style.color = CSS.peach; freshLink.style.borderBottomColor = CSS.peach; });
    freshLink.addEventListener('mouseleave', () => { freshLink.style.color = CSS.lav; freshLink.style.borderBottomColor = CSS.lav; });
    freshLink.addEventListener('click', async () => {
      if (!confirm('Redo all candidates from scratch? Your saved zip is still in Past Downloads.')) return;
      downloaded.clear();
      skipped.clear();
      csvRows = [];
      skippedDetails = [];
      skippedPanelList.innerHTML = '';
      await clearResumesForJob(KEY);
      persist();
      updateStats();
      setProgress(0, 0);
      if (progressText) progressText.textContent = '';
      if (statTimeLeft) statTimeLeft.textContent = '--';
      controlBtn.textContent = 'Start';
      controlBtn.style.background = CSS.mintGrad;
      controlBtn.style.color = '#fff';
      setStatus('Ready — cleared for fresh scan');
      statusFreshLink.style.display = 'none';
      downloadZipBtn.style.display = 'none';
    });
    statusFreshLink.appendChild(freshLink);

    // Progress bar (lavender by default, mint when done)
    const progressWrap = el('div', {
      marginTop: '12px', background: CSS.progressBg,
      borderRadius: '20px', height: '8px', overflow: 'hidden',
      position: 'relative'
    });
    progressBarFill = el('div', {
      height: '100%', width: '0%',
      background: CSS.progressFill,
      borderRadius: '20px',
      transition: 'width 0.4s ease',
      backgroundSize: '200% 100%',
      animation: 'sid-shimmer 2s linear infinite'
    });
    progressWrap.appendChild(progressBarFill);

    progressText = el('div', {
      textAlign: 'center', fontSize: '10px', color: CSS.textDim,
      marginTop: '4px'
    });

    // Stats grid (3 columns: Processed, Skipped, Time Left)
    const statsGrid = el('div', {
      display: 'grid', gridTemplateColumns: '1fr 1fr 1fr',
      gap: '8px', marginTop: '12px'
    });

    function statCard(label, color, isClickable = false) {
      const card = el('div', {
        background: CSS.bgCard, borderRadius: CSS.radiusSm,
        padding: '8px 10px', textAlign: 'center',
        border: `1px solid ${CSS.bgCardBorder}`,
        cursor: isClickable ? 'pointer' : 'default',
        transition: isClickable ? 'background 0.15s' : 'none'
      });
      if (isClickable) {
        card.addEventListener('mouseenter', () => card.style.background = CSS.bgHover);
        card.addEventListener('mouseleave', () => card.style.background = CSS.bgCard);
      }
      const val = el('div', {
        fontSize: '18px', fontWeight: '700', color: color,
        lineHeight: '1.2'
      }, '0');
      const lbl = el('div', {
        fontSize: '9px', color: CSS.textDim, textTransform: 'uppercase',
        letterSpacing: '0.5px', marginTop: '2px'
      }, label);
      card.append(val, lbl);
      return { card, val };
    }

    const procCard = statCard('Processed', CSS.mint);
    const skipCard = statCard('Skipped', CSS.peach, true);  // clickable
    const timeCard = statCard('Time Left', CSS.lav);
    statProcessed = procCard.val;
    statSkip = skipCard.val;
    statTimeLeft = timeCard.val;

    // Open skipped panel when clicking skip card
    skipCard.card.addEventListener('click', () => {
      const isOpen = skippedPanel.style.display !== 'none';
      skippedPanel.style.display = isOpen ? 'none' : 'block';
      historyPanel.style.display = 'none'; // close history if open
    });

    statsGrid.append(procCard.card, skipCard.card, timeCard.card);

    // Skipped panel (hidden by default)
    skippedPanel = el('div', {
      display: 'none', marginTop: '12px',
      background: CSS.bgCard, borderRadius: CSS.radiusSm,
      border: `1px solid ${CSS.bgCardBorder}`,
      overflow: 'hidden'
    });

    const skippedHeader = el('div', {
      padding: '8px 10px',
      background: CSS.bgCardBorder,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      fontSize: '11px', fontWeight: '600', color: CSS.text
    });
    skippedHeader.textContent = 'Skipped Candidates';

    const skippedCloseBtn = el('button', {
      background: 'transparent', border: 'none', color: CSS.textDim,
      cursor: 'pointer', fontSize: '14px', padding: '0', lineHeight: '1'
    }, '×');
    skippedCloseBtn.addEventListener('click', () => {
      skippedPanel.style.display = 'none';
    });
    skippedHeader.appendChild(skippedCloseBtn);

    skippedPanelList = el('div', {
      maxHeight: '130px', overflowY: 'auto',
      fontSize: '10px'
    });

    skippedPanel.append(skippedHeader, skippedPanelList);

    // Past Downloads panel (hidden by default)
    historyPanel = el('div', {
      display: 'none', marginTop: '12px',
      background: CSS.bgCard, borderRadius: CSS.radiusSm,
      border: `1px solid ${CSS.bgCardBorder}`,
      overflow: 'hidden'
    });

    const historyHeader = el('div', {
      padding: '8px 10px',
      background: CSS.bgCardBorder,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      fontSize: '11px', fontWeight: '600', color: CSS.text
    });
    historyHeader.textContent = 'Job History';

    const historyCloseBtn = el('button', {
      background: 'transparent', border: 'none', color: CSS.textDim,
      cursor: 'pointer', fontSize: '14px', padding: '0', lineHeight: '1'
    }, '×');
    historyCloseBtn.addEventListener('click', () => {
      historyPanel.style.display = 'none';
    });
    historyHeader.appendChild(historyCloseBtn);

    historyPanelList = el('div', {
      maxHeight: '130px', overflowY: 'auto',
      fontSize: '10px'
    });

    const historyFooter = el('div', {
      padding: '6px 10px',
      borderTop: `1px solid ${CSS.bgCardBorder}`,
      textAlign: 'center'
    });

    const clearHistoryBtn = el('button', {
      background: 'transparent', border: 'none',
      color: CSS.textDim, fontSize: '10px',
      cursor: 'pointer', padding: '4px 0',
      transition: 'color 0.15s'
    }, 'Clear All History');
    clearHistoryBtn.addEventListener('mouseenter', () => clearHistoryBtn.style.color = CSS.peach);
    clearHistoryBtn.addEventListener('mouseleave', () => clearHistoryBtn.style.color = CSS.textDim);
    clearHistoryBtn.addEventListener('click', async () => {
      if (!confirm('Clear download history? (This does not delete files)')) return;
      // Clear current job state
      downloaded.clear();
      skipped.clear();
      csvRows = [];
      skippedDetails = [];
      // Clear ALL data from IndexedDB (resumes + job data)
      try { indexedDB.deleteDatabase('SID_Resumes'); } catch (e) { /* ignore */ }
      // Also clean any leftover localStorage keys
      const keysToRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('sid_dl_')) keysToRemove.push(k);
      }
      keysToRemove.forEach(k => localStorage.removeItem(k));
      skippedPanelList.innerHTML = '';
      refreshHistoryList();
      updateStats();
      setStatus('History cleared');
      downloadZipBtn.style.display = 'none';
      updateDownloadAllBtn();
    });

    historyFooter.appendChild(clearHistoryBtn);
    historyPanel.append(historyHeader, historyPanelList, historyFooter);

    // Divider
    const divider = el('div', {
      height: '1px', background: CSS.divider, margin: '12px 0 8px 0'
    });

    // Download Zip button — lavender gradient (prominent)
    downloadZipBtn = el('button', {
      width: '100%', padding: '8px 0', marginTop: '0',
      border: 'none',
      borderRadius: CSS.radiusSm, background: 'linear-gradient(135deg, #fce4ec, #f4d4de)',
      color: '#6b2d4a', fontSize: '12px', fontWeight: '600', cursor: 'pointer',
      transition: 'all 0.15s', display: 'none'
    }, 'Download Zip');
    downloadZipBtn.className = 'sid-btn';
    downloadZipBtn.addEventListener('click', () => {
      if (csvRows.length === 0) return;
      flushCSV();
      const jobName = (csvRows[0]?.jobTitle || 'candidates').replace(/[^a-zA-Z0-9 ]/g, '').replace(/\s+/g, '_');
      const csvContent = generateCSV(csvRows);
      generateAndDownloadZip(csvRows[0]?.jobTitle || 'candidates', csvContent);
    });

    // Download All Today button — extra light butter
    const downloadAllBtn = el('button', {
      width: '100%', padding: '7px 0', marginTop: '6px',
      border: 'none',
      borderRadius: CSS.radiusSm, background: 'linear-gradient(135deg, #f8f3e2, #f2ebd0)',
      color: '#5c5228', fontSize: '11px', fontWeight: '600',
      cursor: 'pointer', transition: 'all 0.15s', display: 'none'
    }, 'Download All Today');
    downloadAllBtn.className = 'sid-btn';
    downloadAllBtn.addEventListener('mouseenter', () => { downloadAllBtn.style.background = 'linear-gradient(135deg, #f2ebd0, #ece3c0)'; });
    downloadAllBtn.addEventListener('mouseleave', () => { downloadAllBtn.style.background = 'linear-gradient(135deg, #f8f3e2, #f2ebd0)'; });
    downloadAllBtn.addEventListener('click', () => generateAllJobsZip());

    // Count today's jobs and unique resumes from IndexedDB CSV store
    updateDownloadAllBtn = async function() {
      const today = toEasternDateStr();
      // Count unique resumes saved TODAY (by per-resume timestamp, not job-level savedDate)
      let totalResumes = 0;
      const todayJobKeys = new Set();
      try {
        const allResumes = await getAllResumes();
        const seen = new Set();
        const seenFiles = new Set();
        for (const r of allResumes) {
          // Filter by individual resume timestamp — only include resumes saved today
          if (r.timestamp && toEasternDateStr(r.timestamp) !== today) continue;
          const dedupKey = r.legacyId || r.candidateId;
          if (dedupKey && seen.has(dedupKey)) continue;
          if (dedupKey) seen.add(dedupKey);
          if (r.filename && seenFiles.has(r.filename)) continue;
          if (r.filename) seenFiles.add(r.filename);
          todayJobKeys.add(r.jobKey);
          totalResumes++;
        }
      } catch (e) { /* fallback: leave at 0 */ }
      const jobCount = todayJobKeys.size;
      if (jobCount >= 1) {
        downloadAllBtn.innerHTML = `Download All Today<span style="font-weight:400;opacity:0.7;margin-left:4px">${jobCount} job${jobCount === 1 ? '' : 's'} · ${totalResumes} resume${totalResumes === 1 ? '' : 's'}</span>`;
        downloadAllBtn.style.display = 'block';
      } else {
        downloadAllBtn.style.display = 'none';
      }
    };

    // Job History button — extra light sky
    const pastDownloadsBtn = el('button', {
      width: '100%', padding: '6px 0', marginTop: '6px',
      border: 'none',
      borderRadius: CSS.radiusSm, background: 'linear-gradient(135deg, #e0eefb, #d4e6f6)',
      color: '#2a4d6b', fontSize: '11px', cursor: 'pointer',
      transition: 'all 0.15s'
    }, 'Job History ▼');
    pastDownloadsBtn.className = 'sid-btn';
    pastDownloadsBtn.addEventListener('mouseenter', () => { pastDownloadsBtn.style.background = 'linear-gradient(135deg, #d4e6f6, #c8deee)'; });
    pastDownloadsBtn.addEventListener('mouseleave', () => { pastDownloadsBtn.style.background = 'linear-gradient(135deg, #e0eefb, #d4e6f6)'; });
    pastDownloadsBtn.addEventListener('click', () => {
      const isOpen = historyPanel.style.display !== 'none';
      historyPanel.style.display = isOpen ? 'none' : 'block';
      skippedPanel.style.display = 'none'; // close skipped if open
      if (!isOpen) refreshHistoryList();
    });

    // Refresh history list
    async function refreshHistoryList() {
      historyPanelList.innerHTML = '';
      const jobs = [];
      // Load job history from IndexedDB CSV store
      const allCsvData = await getAllCSV();
      for (const csvEntry of allCsvData) {
        const csv = csvEntry.rows || [];
        if (csv.length === 0) continue;
        const title = csv[0]?.jobTitle || 'Unknown Job';
        const company = csv[0]?.company || '';
        const count = csv.length;
        jobs.push({ key: csvEntry.jobKey, title, company, count, csv, savedAt: csvEntry.savedAt || 0, savedDate: csvEntry.savedDate });
      }
      if (jobs.length === 0) {
        const empty = el('div', { padding: '10px', fontSize: '10px', color: CSS.textDim, textAlign: 'center' });
        empty.textContent = 'No saved data';
        historyPanelList.appendChild(empty);
        return;
      }
      // Sort by savedAt descending, falling back to savedDate
      jobs.sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0) || (b.savedDate || '').localeCompare(a.savedDate || ''));
      for (const job of jobs) {
        const row = el('div', {
          padding: '6px 10px', cursor: 'pointer',
          borderBottom: `1px solid ${CSS.bgCardBorder}`,
          color: CSS.text,
          transition: 'background 0.1s'
        });
        row.className = 'sid-item';
        row.addEventListener('mouseenter', () => row.style.background = CSS.bgHover);
        row.addEventListener('mouseleave', () => row.style.background = 'transparent');
        const label = `${job.title}${job.company ? ' — ' + job.company : ''}`;
        row.innerHTML = `<div style="font-weight:500;margin-bottom:2px;font-size:10px">${label}</div><div style="font-size:9px;color:${CSS.textDim}">${job.count} candidates</div>`;
        row.addEventListener('click', () => {
          const csvContent = generateCSV(job.csv);
          generateAndDownloadZip(job.csv[0]?.jobTitle || 'candidates', csvContent, job.key);
          historyPanel.style.display = 'none';
        });
        historyPanelList.appendChild(row);
      }
    }

    bodyWrap.append(
      controlBtn, statusEl, statusFreshLink, progressWrap, progressText, statsGrid,
      skippedPanel, historyPanel, divider, downloadZipBtn, downloadAllBtn, pastDownloadsBtn
    );
    box.append(headerBar, bodyWrap);
    box.id = 'sid-widget';
    document.body.appendChild(box);

    // --- Drag ---
    let drag = false, dx = 0, dy = 0;
    headerBar.addEventListener('mousedown', e => {
      if (e.target.tagName === 'BUTTON' || e.target.closest('button')) return;
      drag = true; dx = e.clientX - box.offsetLeft; dy = e.clientY - box.offsetTop;
      headerBar.style.cursor = 'grabbing';
    });
    document.addEventListener('mousemove', e => {
      if (!drag) return;
      box.style.left = Math.max(0, Math.min(innerWidth - box.offsetWidth, e.clientX - dx)) + 'px';
      box.style.top  = Math.max(0, Math.min(innerHeight - box.offsetHeight, e.clientY - dy)) + 'px';
      box.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => { if (drag) { drag = false; headerBar.style.cursor = 'move'; } });

    // --- Control button event ---
    controlBtn.addEventListener('click', () => {
      if (!running) {
        running = true;
        controlBtn.textContent = 'Stop';
        controlBtn.style.background = CSS.peachGrad;
        controlBtn.style.color = '#fff';
        statusFreshLink.style.display = 'none'; // hide start fresh while running
        run();
      } else {
        // Pause — set running=false so the run() loop exits gracefully.
        // run() will detect the pause and set the proper "Paused" status + Resume button.
        running = false;
        controlBtn.textContent = 'Resume';
        controlBtn.style.background = CSS.mintGrad;
        controlBtn.style.color = '#fff';
        setStatus('Pausing...');
        statusFreshLink.style.display = 'none';
      }
    });

    updateStats();
    showIdleState();
    updateDownloadAllBtn();

    // --- Auto-detect job change or navigation away (SPA navigation) ---
    let lastUrl = window.location.href;
    let lastOnCandidatePage = /\/candidates\/view/.test(lastUrl);
    let _navBusy = false; // prevent overlapping async handlers
    const widget = document.getElementById('sid-widget');

    setInterval(async () => {
      if (_navBusy) return; // previous async handler still running
      const currentUrl = window.location.href;
      const onCandidatePage = /\/candidates\/view/.test(currentUrl);
      const urlChanged = currentUrl !== lastUrl;

      if (urlChanged) {
        lastUrl = currentUrl;
      }

      // --- CASE 1: Not on a candidate page ---
      if (!onCandidatePage && widget) {
        if (urlChanged || lastOnCandidatePage) {
          // Just left candidates — reset visual state but KEEP data
          running = false;
          controlBtn.textContent = 'Start';
          controlBtn.style.background = CSS.mintGrad;
          controlBtn.style.color = '#fff';
          setProgress(0, 0);
          if (progressText) progressText.textContent = '';
          if (statProcessed) statProcessed.textContent = '0';
          if (statSkip) statSkip.textContent = '0';
          if (statTimeLeft) statTimeLeft.textContent = '0';
          statusFreshLink.style.display = 'none';
          skippedDetails = [];
          if (skippedPanelList) skippedPanelList.innerHTML = '';
          if (downloaded.size > 0) {
            setStatus('Navigate to a job to start — or download below');
            downloadZipBtn.style.display = 'block';
          } else {
            setStatus('Ready');
            downloadZipBtn.style.display = 'none';
          }
          updateDownloadAllBtn();
          console.log('[SID] Navigated away from candidates — visual reset (data preserved)');
        }
        lastOnCandidatePage = false;
        return;
      }

      // --- CASE 2: On a candidate page ---
      // Run job-switch logic if URL changed OR we just arrived on a candidate page
      if (urlChanged || !lastOnCandidatePage) {
        _navBusy = true;
        try {
          const oldKey = KEY;
          await refreshStorageKey();
          // Always update widget when arriving on a candidate page (even if key didn't change)
          if (oldKey !== KEY || !lastOnCandidatePage) {
            skippedDetails = [];
            if (skippedPanelList) skippedPanelList.innerHTML = '';
            if (!running) {
              downloadZipBtn.style.display = 'none';
              setProgress(0, 0);
              if (progressText) progressText.textContent = '';
              if (statTimeLeft) statTimeLeft.textContent = '0';
              controlBtn.textContent = 'Start';
              controlBtn.style.background = CSS.mintGrad;
              controlBtn.style.color = '#fff';
            }
            updateStats();
            showIdleState();
            if (downloaded.size === 0 && skipped.size === 0) {
              setStatus('Ready');
              statusFreshLink.style.display = 'none';
              downloadZipBtn.style.display = 'none';
            }
            console.log(`[SID] On candidate page — KEY="${KEY}", ${downloaded.size} done, ${skipped.size} skipped`);
            updateDownloadAllBtn();
          }
        } finally {
          _navBusy = false;
        }
      }
      lastOnCandidatePage = onCandidatePage;
    }, 1000);
  }

  function setStatus(t) {
    if (statusEl) {
      statusEl.textContent = t;
      statusEl.title = t; // for long text on hover
    }
  }

  function setProgress(current, total) {
    if (!total) {
      progressBarFill.style.width = '0%';
      progressBarFill.style.background = CSS.progressFill;
      progressText.textContent = '';
      return;
    }
    const pct = Math.min(100, Math.round((current / total) * 100));
    progressBarFill.style.width = pct + '%';
    if (pct === 100) {
      progressBarFill.style.background = CSS.progressDone;
    } else {
      progressBarFill.style.background = CSS.progressFill;
    }
    progressText.textContent = `${current} of ${total} (${pct}%)`;
  }

  function updateStats() {
    if (statProcessed) statProcessed.textContent = downloaded.size - _statsBaselineDownloaded;
    if (statSkip) statSkip.textContent = skipped.size - _statsBaselineSkipped;
    // Show download zip button as soon as there's CSV data
    if (csvRows.length > 0 && downloadZipBtn) downloadZipBtn.style.display = 'block';
  }

  // Show the idle context when returning to a job that was already run
  function showIdleState() {
    if (running) return;
    // Reset baselines so stat boxes show cumulative totals when idle
    _statsBaselineDownloaded = 0;
    _statsBaselineSkipped = 0;
    const total = downloaded.size + skipped.size;
    if (total > 0 && statusFreshLink) {
      setStatus(`${downloaded.size} already downloaded — Start grabs new only`);
      statusFreshLink.style.display = 'block';
      updateStats();
    } else if (statusFreshLink) {
      statusFreshLink.style.display = 'none';
    }
  }

  const MIN_SAMPLES = 10;
  let _lastTimeLeftUpdate = 0;
  const TIME_LEFT_UPDATE_MS = 3000;

  function updateTimeLeft(remaining, totalDone) {
    if (!startTime || totalDone < MIN_SAMPLES || remaining <= 0) {
      if (statTimeLeft) statTimeLeft.textContent = '--';
      return;
    }
    const now = Date.now();
    if (now - _lastTimeLeftUpdate < TIME_LEFT_UPDATE_MS && statTimeLeft.textContent !== '--') return;
    _lastTimeLeftUpdate = now;
    const elapsed = (now - startTime) / 1000;
    const perSec = totalDone / elapsed;
    const secsLeft = perSec > 0 ? remaining / perSec : 0;
    if (secsLeft < 60) {
      statTimeLeft.textContent = `${Math.round(secsLeft)}s`;
    } else if (secsLeft < 3600) {
      statTimeLeft.textContent = `${Math.round(secsLeft / 60)}m`;
    } else {
      const h = Math.floor(secsLeft / 3600);
      const m = Math.round((secsLeft % 3600) / 60);
      statTimeLeft.textContent = `${h}h ${m}m`;
    }
  }

  function addSkipped(id, name, reason, detail) {
    // Add to skippedDetails array
    skippedDetails.push({ id, name, reason, detail });

    // Update UI
    const reasonLabel = {
      'intl': 'International',
      'no_resume': 'No Resume',
      'error': 'Error',
      'withdrawn': 'Withdrawn'
    }[reason] || reason;

    const reasonBg = {
      'intl': '#e8e0f5',
      'no_resume': '#fce8e0',
      'error': '#fceee0',
      'withdrawn': '#e8e8ee'
    }[reason] || '#ddd8ec';

    const reasonColor = {
      'intl': '#8a70b0',
      'no_resume': '#c07050',
      'error': '#b88040',
      'withdrawn': '#808098'
    }[reason] || CSS.textDim;

    const item = el('div', {
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '6px 10px',
      borderBottom: `1px solid ${CSS.bgCardBorder}`,
      fontSize: '10px'
    });
    item.className = 'sid-item';

    const nameSpan = el('span', { color: CSS.text }, name);
    const reasonTag = el('span', {
      background: reasonBg, color: reasonColor,
      padding: '2px 6px', borderRadius: '3px',
      fontSize: '9px', fontWeight: '500'
    }, reasonLabel);

    item.append(nameSpan, reasonTag);
    skippedPanelList.appendChild(item);
  }

  function removeFromSkippedPanel(id) {
    skippedDetails = skippedDetails.filter(d => d.id !== id);
    // Rebuild list
    skippedPanelList.innerHTML = '';
    for (const detail of skippedDetails) {
      const reasonLabel = {
        'intl': 'International',
        'no_resume': 'No Resume',
        'error': 'Error',
        'withdrawn': 'Withdrawn'
      }[detail.reason] || detail.reason;

      const reasonBg = {
        'intl': '#e8e0f5',
        'no_resume': '#fce8e0',
        'error': '#fceee0',
        'withdrawn': '#e8e8ee'
      }[detail.reason] || '#ddd8ec';

      const reasonColor = {
        'intl': '#8a70b0',
        'no_resume': '#c07050',
        'error': '#b88040',
        'withdrawn': '#808098'
      }[detail.reason] || CSS.textDim;

      const item = el('div', {
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '6px 10px',
        borderBottom: `1px solid ${CSS.bgCardBorder}`,
        fontSize: '10px'
      });

      const nameSpan = el('span', { color: CSS.text }, detail.name);
      const reasonTag = el('span', {
        background: reasonBg, color: reasonColor,
        padding: '2px 6px', borderRadius: '3px',
        fontSize: '9px', fontWeight: '500'
      }, reasonLabel);

      item.append(nameSpan, reasonTag);
      skippedPanelList.appendChild(item);
    }
  }

  // ================================================
  // Batch mark-as-reviewed
  // ================================================
  async function batchMarkAsReviewed(reviewQueue, csrf) {
    if (reviewQueue.length === 0) return;

    setStatus(`Marking ${reviewQueue.length} as reviewed...`);
    console.log(`[SID] Batch marking ${reviewQueue.length} candidates as reviewed...`);

    const CHUNK = 50;
    let marked = 0;
    for (let i = 0; i < reviewQueue.length; i += CHUNK) {
      const chunk = reviewQueue.slice(i, i + CHUNK);
      const payload = {
        operationName: 'UpdateCandidateStatus',
        extensions: {},
        variables: {
          statusInput: {
            move: {
              milestoneId: 'REVIEWED',
              candidateSubmissionEmployerJobIdPairs: chunk.map(c => ({
                candidateSubmissionId: c.candidateSubmissionId,
                jobId: c.jobId
              }))
            }
          }
        },
        query: 'mutation UpdateCandidateStatus($statusInput: UpdateCandidateSubmissionMilestoneInput!) {\n  updateCandidateSubmissionMilestone(input: $statusInput) {\n    candidateSubmissionMilestone {\n      category\n      milestoneId\n      __typename\n    }\n    __typename\n  }\n}'
      };

      try {
        const resp = await graphqlFetch('https://apis.indeed.com/graphql?co=US&locale=en-US', payload);
        if (resp.ok && resp.data) {
          const milestone = resp.data?.data?.updateCandidateSubmissionMilestone?.candidateSubmissionMilestone?.milestoneId;
          marked += chunk.length;
          console.log(`[SID] Batch reviewed ${marked}/${reviewQueue.length} (milestone: ${milestone})`);
        } else {
          console.warn(`[SID] Batch mark-as-reviewed HTTP ${resp.status}`, JSON.stringify(resp.data || resp.error).substring(0, 200));
        }
      } catch (e) {
        console.warn(`[SID] Batch mark-as-reviewed error:`, e);
      }
      if (i + CHUNK < reviewQueue.length) await wait(500);
    }

    console.log(`[SID] Finished marking ${marked}/${reviewQueue.length} as reviewed`);
    return marked;
  }

  // ================================================
  // React fiber extraction helpers
  // ================================================
  // Cached job info — populated once from the first candidate that has job.node
  let _cachedJobInfo = { title: '', company: '', location: '', jobGraphQLId: null };

  // Extract raw candidate object from a sidebar li element's React fiber
  function _getCandidateFromFiber(li) {
    const fiberKey = Object.keys(li).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
    if (!fiberKey) return null;
    const fiber = li[fiberKey];
    try {
      const c = fiber.memoizedProps?.children?.props?.candidate;
      if (c && c.id) return c;
      const props = fiber.memoizedProps || {};
      for (const k of Object.keys(props)) {
        const v = props[k];
        if (v && typeof v === 'object' && v.props && v.props.candidate) {
          const c2 = v.props.candidate;
          if (c2 && c2.id) return c2;
        }
      }
    } catch (e) { /* ignore */ }
    return null;
  }

  // Extract job info from a candidate object
  // Data lives at job.node.jobData (not job.node directly)
  function _extractJobInfo(c) {
    const jobData = c.job?.node?.jobData || c.job?.node || {};
    const aggJob = c.aggJob || {};
    const empJob = aggJob.employerJob || {};
    const title = jobData.title || empJob.title || '';
    const company = jobData.company || empJob.company || '';
    const location = jobData.location?.formatted?.short || empJob.location?.formatted?.short || '';
    return { title, company, location };
  }

  // Cache job info from the first sidebar candidate's React fiber
  function cacheJobInfo() {
    const items = document.querySelectorAll('li[data-testid="CandidateListItem"][id^="candidate-tab-"]');
    for (const li of items) {
      const c = _getCandidateFromFiber(li);
      if (!c) continue;
      const info = _extractJobInfo(c);
      if (info.title || info.company) {
        _cachedJobInfo = info;
        _cachedJobInfo.jobGraphQLId = c.job?.id || null;
        _cachedJobInfo.allJobIds = [...new Set([
          c.job?.id,
          c.aggJob?.employerJob?.id,
          c.aggJob?.id,
          c.job?.node?.id
        ].filter(Boolean))];
        console.log(`[SID] Cached job info: "${info.title}" at "${info.company}" (${info.location}) [graphqlId=${_cachedJobInfo.jobGraphQLId ? 'found' : 'missing'}]`);
        console.log(`[SID] All job IDs found (${_cachedJobInfo.allJobIds.length}):`, _cachedJobInfo.allJobIds);
        return;
      }
    }
    console.warn('[SID] Could not cache job info from fiber data');
  }

  function getCandidateReactData(candidateId) {
    const li = document.querySelector(`#candidate-tab-${candidateId}`);
    if (!li) return null;
    const c = _getCandidateFromFiber(li);

    function extractFromCandidate(c) {
      if (!c || !c.id || !c.applyJobId) return null;
      const jobData = c.job?.node?.jobData || c.job?.node || {};
      const aggJob = c.aggJob || {};
      const empJob = aggJob.employerJob || {};
      return {
        // IDs needed for mark-as-reviewed
        candidateSubmissionId: c.id,
        jobId: c.applyJobId,
        jobGraphQLId: c.job?.id || null,
        // Profile data for CSV
        name: c.profile?.name?.displayName || '',
        email: c.profile?.contact?.email || '',
        phone: c.profile?.contact?.phoneNumber || '',
        location: c.profile?.location?.location || '',
        country: c.profile?.location?.country || '',
        // Job data — lives at job.node.jobData, with cached fallback
        jobTitle: jobData.title || empJob.title || _cachedJobInfo.title,
        company: jobData.company || empJob.company || _cachedJobInfo.company,
        jobLocation: jobData.location?.formatted?.short || empJob.location?.formatted?.short || _cachedJobInfo.location,
        dateApplied: c.created ? toEasternDateStr(c.created) : '',
        // Source attribution — Sponsored, Organic, or Unknown
        source: (() => {
          const src = (c.sources || [])[0] || {};
          const attr = (src.attributionList || [])[0] || '';
          if (attr === 'SPONSORED_JOBS' || (src.sourceType || '').includes('SPONSORED')) return 'Sponsored';
          if (attr === 'ORGANIC_JOBS') return 'Organic';
          return 'Unknown';
        })(),
        legacyId: c.legacyID || candidateId,
        // Milestone/status for skip detection
        milestoneCategory: c.milestone?.milestone?.category || '',
        milestoneId: c.milestone?.milestone?.milestoneId || ''
      };
    }

    if (c) {
      const result = extractFromCandidate(c);
      if (result) return result;
    }
    return null;
  }

  async function clickLoadMore() {
    try {
      // Search buttons first, then any clickable element with "Load more" text
      let btn = [...document.querySelectorAll('button')]
        .find(b => /load\s*more/i.test(b.textContent));
      if (!btn) {
        // Broader search: any element with "Load more" text
        btn = [...document.querySelectorAll('a, div, span, [role="button"]')]
          .find(el => /load\s*more/i.test(el.textContent) && el.offsetParent !== null);
      }
      if (!btn) {
        console.log('[SID] Load more button not found');
        return false;
      }
      btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await wait(300);
      btn.click();
      console.log(`[SID] Clicked Load more (${btn.tagName})`);
      await wait(LOAD_MORE_PAUSE_MS);
      return true;
    } catch (e) {
      console.warn('[SID] clickLoadMore error:', e);
      return false;
    }
  }

  // ================================================
  // Main loop — batch processing with auto-retry
  // ================================================
  let _runActive = false; // guard against reentry during post-loop cleanup
  async function run() {
    if (_runActive) return; // previous run still winding down
    _runActive = true;
    // Wait for IndexedDB init to complete before running (prevents re-downloading everything)
    if (!_initLoaded) {
      setStatus('Loading saved state...');
      const initData = await loadJobData(KEY);
      if (initData) {
        if (initData.done && initData.done.length > 0) downloaded = new Set(initData.done);
        if (initData.skip && initData.skip.length > 0) skipped = new Set(initData.skip);
        if (initData.rows && initData.rows.length > 0) csvRows = initData.rows;
      }
      _initLoaded = true;
    }
    // Check if we navigated to a different job listing
    await refreshStorageKey();
    updateStats();

    setStatus('Finding CSRF token...');
    const csrf = getCSRFToken();
    if (!csrf) {
      setStatus('No CSRF token found — reload the page');
      running = false;
      _runActive = false;
      controlBtn.textContent = 'Start';
      controlBtn.style.background = CSS.mintGrad;
      controlBtn.style.color = '#fff';
      return;
    }

    let emptyLoads = 0;
    startTime = Date.now();
    dlCount = 0;
    let intlCount = 0;
    const processed = new Set([...downloaded, ...skipped]);
    const alreadyDone = processed.size;
    let totalProcessed = alreadyDone;
    const reviewQueue = [];
    const retryQueue = [];

    // --- Get initial total from page "X of Y" ---
    let displayTotal = getTotalFromPage() || 0;
    const originalPageTotal = displayTotal;   // preserve for recovery cap
    // Detect "filtered/new-only" run — widget should show progress against the
    // currently-visible filter, not against the user's all-time done count.
    // Two signals that trigger filtered-run mode:
    //   A) Old: page total <= already-done (resuming on a tab that shows fewer
    //      candidates than we've ever processed for this jobKey).
    //   B) New (v5.8.10): the visible sidebar candidates are uniformly in one
    //      milestone (e.g., all NEW) AND barely any overlap with already-done.
    //      This catches "user is on the New tab with 368 fresh candidates and 167
    //      old-but-from-other-tabs in their processed set" — the case where the
    //      widget was incorrectly starting at 167/368 instead of 0/368.
    let isNewOnlyRun = false;
    _statsBaselineDownloaded = 0;
    _statsBaselineSkipped = 0;
    // --- Signal A: numeric heuristic (resuming on a tab smaller than done count) ---
    if (displayTotal > 0 && alreadyDone > 0 && displayTotal <= alreadyDone) {
      isNewOnlyRun = true;
      console.log(`[SID] Filtered-run detected (numeric): page shows ${displayTotal}, ${alreadyDone} already done`);
    }
    // --- Signal B: URL's listQuery has a statusName filter ---
    // Indeed encodes the active tab/filter as `statusName=...` inside listQuery.
    // If present and not 'All', we're on a filtered tab and the widget should
    // count this run only, not include prior history.
    if (!isNewOnlyRun) {
      try {
        const _params = new URLSearchParams(window.location.search);
        const _lq = _params.get('listQuery') || '';
        if (_lq) {
          const _decoded = atob(_lq);
          const _dp = new URLSearchParams(decodeURIComponent(_decoded));
          const _status = (_dp.get('statusName') || '').trim();
          if (_status && _status.toLowerCase() !== 'all') {
            isNewOnlyRun = true;
            console.log(`[SID] Filtered-run detected (URL statusName="${_status}"): page shows ${displayTotal}, ${alreadyDone} already done elsewhere`);
          }
        }
      } catch (e) { /* listQuery not decodable — fall through */ }
    }
    // --- Signal C: overlap heuristic (most visible candidates are NOT in processed) ---
    // Catches filtered views even when statusName missing from URL.
    if (!isNewOnlyRun && alreadyDone > 0) {
      const _ids = getCandidateIds();
      if (_ids.length > 0) {
        let _overlapWithProcessed = 0;
        for (const id of _ids) if (processed.has(id)) _overlapWithProcessed++;
        const _overlapRatio = _overlapWithProcessed / _ids.length;
        // If almost none of the visible candidates are already-done, the page
        // is filtered to fresh candidates. Permissive threshold of 20%.
        if (_overlapRatio <= 0.2) {
          isNewOnlyRun = true;
          console.log(`[SID] Filtered-run detected (low overlap): ${_ids.length} visible, ${_overlapWithProcessed} (${Math.round(_overlapRatio*100)}%) overlap with already-done`);
        }
      }
    }
    if (isNewOnlyRun) {
      _statsBaselineDownloaded = downloaded.size;
      _statsBaselineSkipped = skipped.size;
    }
    // For new-only runs, widget shows progress against new candidates only
    const widgetTotal = () => displayTotal;
    const widgetProcessed = () => isNewOnlyRun ? (totalProcessed - alreadyDone) : totalProcessed;
    // For recovery: how many THIS RUN should process vs how many have been done this run
    const thisRunDone = () => totalProcessed - alreadyDone;

    if (displayTotal > 0) {
      if (isNewOnlyRun) {
        setStatus(`${displayTotal} new candidates (${_statsBaselineDownloaded} previously downloaded)`);
      } else if (alreadyDone > 0) {
        setStatus(`Resuming — ${alreadyDone} already done, ${displayTotal - alreadyDone} remaining`);
      } else {
        setStatus(`${displayTotal} candidates found`);
      }
      setProgress(widgetProcessed(), widgetTotal());
    } else {
      setStatus('Scanning candidates...');
    }

    cacheJobInfo();

    // --- Capture the clicked candidate BEFORE processing starts ---
    // On the New tab, clicking the first candidate moves them to "Reviewing",
    // which removes them from the New list. Capture their ID and React data now
    // so we can process them even if they disappear from the sidebar.
    const initialIds = getCandidateIds();
    const clickedCandidateId = initialIds.length > 0 ? initialIds[0] : null;
    const clickedCandidateReact = clickedCandidateId ? getCandidateReactData(clickedCandidateId) : null;
    const clickedCandidateName = clickedCandidateId ? (getNameForId(clickedCandidateId) || '') : '';
    if (clickedCandidateId) {
      console.log(`[SID] Captured clicked candidate: ${clickedCandidateId} — ${clickedCandidateName}`);
    }

    while (running) {
      const visibleIds = getCandidateIds();
      const batch = visibleIds.filter(id => !processed.has(id));

      // Re-check page total after each load-more (it may appear or update)
      const pageTotal = getTotalFromPage();
      if (pageTotal > 0) displayTotal = pageTotal;
      if (!displayTotal) displayTotal = Math.max(displayTotal, totalProcessed + batch.length);

      if (batch.length === 0) {
        setStatus('Loading more candidates...');
        const loaded = await clickLoadMore();
        if (!loaded || !running) break;
        emptyLoads++;
        if (emptyLoads >= MAX_EMPTY_LOADS) break;
        continue;
      }

      emptyLoads = 0;

      for (let i = 0; i < batch.length; i++) {
        if (!running) break;

        const id   = batch[i];
        const name = getNameForId(id) || `Candidate ${id.substring(0, 8)}`;
        totalProcessed++;

        const reactData = getCandidateReactData(id);
        const displayName = cleanName(reactData?.name || name);

        const candidateCountry = (reactData?.country || '').toUpperCase();
        const isInternational = candidateCountry && candidateCountry !== 'US' && candidateCountry !== 'CA';

        if (isInternational) {
          const loc = reactData?.location || 'Unknown location';
          console.log(`[SID] Skipping international candidate: ${displayName} (${candidateCountry} — ${loc})`);
          setStatus(`Skipping international: ${displayName}`);
          addSkipped(id, displayName, 'intl', loc + ' (' + candidateCountry + ')');
          skipped.add(id);
          intlCount++;
          if (reactData) {
            reviewQueue.push(reactData);
            csvRows.push({ ...reactData, resumeFile: '', notes: `International — ${loc} (${candidateCountry})` });
          }
          processed.add(id);
          persist();
          updateStats();
          setProgress(widgetProcessed(), widgetTotal());
          if (i < batch.length - 1) await wait(100);
          continue;
        }

        setStatus(`Processing: ${displayName}`);
        setProgress(widgetProcessed(), widgetTotal());
        updateTimeLeft(widgetTotal() - widgetProcessed(), thisRunDone());

        const result = await downloadResume(id, displayName, csrf, reactData);
        if (!running) break;

        const dlStatus = (typeof result === 'object') ? result.status : result;
        const actualFilename = (typeof result === 'object') ? result.filename : null;

        if (dlStatus === 'ok') {
          downloaded.add(id);
          dlCount++;
          if (reactData) {
            reviewQueue.push(reactData);
            csvRows.push({ ...reactData, resumeFile: actualFilename || buildFilename(displayName, '', '', reactData), notes: '' });
          }
          if (!reactData) console.warn(`[SID] No React data for ${id} — won't be marked as reviewed`);
        } else if (dlStatus === 'error') {
          retryQueue.push({ id, name: displayName, reactData });
          skipped.add(id);
          if (reactData) {
            csvRows.push({ ...reactData, resumeFile: '', notes: 'Download error — queued for retry' });
          }
          console.log(`[SID] Queued for retry: ${displayName}`);
        } else {
          // no_resume — skip without retry
          skipped.add(id);
          addSkipped(id, displayName, 'no_resume', '');
          if (reactData) {
            csvRows.push({ ...reactData, resumeFile: '', notes: 'No resume on file' });
          }
        }

        processed.add(id);
        persist();
        updateStats();
        updateTimeLeft(widgetTotal() - widgetProcessed(), thisRunDone());

        if (i < batch.length - 1) await randomWait(400, 700);

        // Staggered session pauses to simulate human browsing (applies to both NEW and ALL runs)
        const domRunCount = thisRunDone();
        if (domRunCount > 0 && domRunCount % 75 === 0) {
          const pauseMs = Math.floor(Math.random() * 10001) + 10000; // 10-20s
          setStatus(`Brief pause (${Math.round(pauseMs / 1000)}s) — ${domRunCount} processed so far...`);
          console.log(`[SID] Session pause after ${domRunCount} candidates: ${Math.round(pauseMs / 1000)}s`);
          await wait(pauseMs);
        } else if (domRunCount > 0 && domRunCount % 25 === 0) {
          const pauseMs = Math.floor(Math.random() * 5001) + 5000; // 5-10s
          setStatus(`Brief pause (${Math.round(pauseMs / 1000)}s) — ${domRunCount} processed so far...`);
          console.log(`[SID] Short pause after ${domRunCount} candidates: ${Math.round(pauseMs / 1000)}s`);
          await wait(pauseMs);
        }
      }

      if (!running) break;

      setStatus('Loading more candidates...');
      // Scroll the sidebar to the bottom to expose the Load More button
      const sidebar = document.querySelector('[class*="candidate"] ul, [class*="Candidate"] ul, nav ul, [role="list"]');
      if (sidebar) sidebar.scrollTop = sidebar.scrollHeight;
      await wait(500);
      let loaded = await clickLoadMore();
      if (!loaded) {
        // Retry: scroll the entire sidebar container
        const containers = document.querySelectorAll('[style*="overflow"], [class*="scroll"]');
        for (const c of containers) {
          if (c.scrollHeight > c.clientHeight + 100) {
            c.scrollTop = c.scrollHeight;
          }
        }
        await wait(500);
        loaded = await clickLoadMore();
      }
      if (!loaded) break;
      await wait(500);
    }

    // ---- PROCESS CLICKED CANDIDATE IF MISSED (New tab N-1 fix) ----
    // If the clicked candidate was never processed (moved to Reviewing and disappeared
    // from the sidebar), process them now using the React data we captured at the start.
    if (running && clickedCandidateId && !processed.has(clickedCandidateId)) {
      console.log(`[SID] Processing missed clicked candidate: ${clickedCandidateId} — ${clickedCandidateName}`);
      const displayName = cleanName(clickedCandidateReact?.name || clickedCandidateName || `Candidate ${clickedCandidateId.substring(0, 8)}`);
      totalProcessed++;
      setStatus(`Processing: ${displayName} (clicked candidate)`);
      setProgress(widgetProcessed(), widgetTotal() + 1);

      const result = await downloadResume(clickedCandidateId, displayName, csrf, clickedCandidateReact);
      const dlStatus = (typeof result === 'object') ? result.status : result;
      const actualFilename = (typeof result === 'object') ? result.filename : null;

      if (dlStatus === 'ok') {
        downloaded.add(clickedCandidateId);
        dlCount++;
        if (clickedCandidateReact) {
          reviewQueue.push(clickedCandidateReact);
          csvRows.push({ ...clickedCandidateReact, resumeFile: actualFilename || buildFilename(displayName, '', '', clickedCandidateReact), notes: '' });
        } else {
          csvRows.push({
            name: displayName, legacyId: clickedCandidateId,
            jobTitle: _cachedJobInfo.title, company: _cachedJobInfo.company, jobLocation: _cachedJobInfo.location,
            resumeFile: actualFilename || `${displayName}.pdf`, notes: ''
          });
        }
      } else if (dlStatus === 'error') {
        retryQueue.push({ id: clickedCandidateId, name: displayName, reactData: clickedCandidateReact });
        skipped.add(clickedCandidateId);
      } else {
        skipped.add(clickedCandidateId);
        addSkipped(clickedCandidateId, displayName, 'no_resume', '');
      }
      processed.add(clickedCandidateId);
      persist();
      updateStats();
    }

    // ---- AUTO-RETRY FAILED DOWNLOADS ----
    if (retryQueue.length > 0 && running) {
      setStatus(`Retrying ${retryQueue.length} failed downloads...`);
      for (const item of retryQueue) {
        if (!running) break;
        const result = await downloadResume(item.id, item.name, csrf, item.reactData);
        const dlStatus = (typeof result === 'object') ? result.status : result;
        if (dlStatus === 'ok') {
          skipped.delete(item.id);
          downloaded.add(item.id);
          dlCount++;
          const actualFilename = (typeof result === 'object') ? result.filename : null;
          if (item.reactData) {
            reviewQueue.push(item.reactData);
            const existingIdx = csvRows.findIndex(r => r.legacyId === item.reactData.legacyId && r.notes && r.notes.includes('error'));
            const retryRow = { ...item.reactData, resumeFile: actualFilename || buildFilename(item.name, '', '', item.reactData), notes: '' };
            if (existingIdx >= 0) {
              csvRows[existingIdx] = retryRow;
            } else {
              csvRows.push(retryRow);
            }
          }
          removeFromSkippedPanel(item.id);
        } else {
          // Still failed — add to skippedDetails with error reason
          addSkipped(item.id, item.name, 'error', 'Download failed after retry');
        }
        persist();
        updateStats();
        await wait(DELAY_BETWEEN_MS);
      }
    }

    // ---- Batch mark as reviewed AFTER all downloads ----
    let marked = 0;
    if (reviewQueue.length > 0 && downloaded.size > 0) {
      marked = await batchMarkAsReviewed(reviewQueue, csrf) || 0;
    }

    // ---- API RECOVERY: catch candidates missed by Load More ----
    // On the "New" tab, clicking the first candidate changes their status to
    // "Reviewing", which causes Load More pagination to serve N-1 candidates.
    // Now that we've marked processed candidates as REVIEWED, query the API
    // for candidates still "NEW" — only the missed one(s) will come back.
    const jobIdsToTry = _cachedJobInfo.allJobIds || [_cachedJobInfo.jobGraphQLId].filter(Boolean);
    if (running && thisRunDone() < (displayTotal || 0) && jobIdsToTry.length > 0) {
      const shortBy = (displayTotal || 0) - thisRunDone();
      console.log(`[SID] Short by ${shortBy} — querying API for missed candidates (this run: ${thisRunDone()} of ${displayTotal}, after marking ${marked} as reviewed)`);
      setStatus('Checking for missed candidates...');

      const recoveryQuery = `query CandidateListIds($input: FindCandidateSubmissionsInput!, $first: Int) {
  findCandidateSubmissions(input: $input, first: $first) {
    candidateSubmissions {
      id
      data {
        __typename
        ... on IndeedApplyCandidateSubmission {
          legacyID
          profile {
            name { displayName __typename }
            location { location country __typename }
            contact { email phoneNumber __typename }
            __typename
          }
          created
          sources { sourceType attributionList __typename }
        }
      }
      __typename
    }
    __typename
  }
}`;

      // Scope recovery to the milestone(s) SID actually saw during the DOM loop.
      // If the user was on a single-milestone filter (e.g. "New" tab), restrict the
      // recovery query to that milestone so we can't sweep up candidates outside it.
      // If milestones were mixed (e.g. "All" tab) or undetectable, fall back to the
      // original broad behavior so nothing regresses.
      const seenMilestones = new Set(
        csvRows.map(r => r && r.milestoneId).filter(Boolean)
      );
      const statusFilters = (seenMilestones.size === 1)
        ? [{ milestoneIds: [[...seenMilestones][0]] }]
        : [
            null,
            { milestoneIds: ['NEW'] },
            { milestoneIds: ['NEW', 'REVIEWING', 'REVIEWED'] }
          ];
      console.log(`[SID] Recovery scope: ${seenMilestones.size === 1 ? 'filtered (' + [...seenMilestones][0] + ')' : 'all (seen ' + seenMilestones.size + ' milestones)'}`);

      let recovered = false;
      for (const tryJobId of jobIdsToTry) {
        if (recovered) break;
        for (const statusFilter of statusFilters) {
          if (recovered) break;
          try {
            const filterLabel = statusFilter ? statusFilter.milestoneIds.join('+') : 'ALL';
            console.log(`[SID] Recovery: trying job ID ${tryJobId.substring(0, 40)}... (filter: ${filterLabel})`);
            const inputFilter = {
              submissionType: 'LEGACY',
              jobs: { employerJobIds: [tryJobId] }
            };
            if (statusFilter) inputFilter.hiringMilestones = statusFilter;

            const apiResp = await graphqlFetch('https://apis.indeed.com/graphql?co=US&locale=en-US', {
              operationName: 'CandidateListIds',
              extensions: {},
              variables: {
                input: { filter: inputFilter },
                first: Math.max(displayTotal || 200, totalProcessed, 200) + 50
              },
              query: recoveryQuery
            });

            if (!apiResp.ok || apiResp.status >= 400) {
              console.warn(`[SID] Recovery API error for job ID (filter: ${filterLabel}) — trying next`);
              continue;
            }

            const submissions = apiResp.data?.data?.findCandidateSubmissions?.candidateSubmissions || [];
            console.log(`[SID] API returned ${submissions.length} candidates (filter: ${filterLabel})`);
            if (submissions.length === 0) continue;

          recovered = true;
          // Update displayTotal to reflect actual candidate count (this run only)
          const unprocessedCount = submissions.filter(s2 => { const lid = s2.data?.legacyID; return lid && !processed.has(lid); }).length;
          const rawRecoveryTotal = thisRunDone() + unprocessedCount;
          if (isNewOnlyRun && originalPageTotal > 0) {
            displayTotal = Math.min(rawRecoveryTotal, originalPageTotal);
            console.log(`[SID] Recovery displayTotal capped at ${displayTotal} (raw ${rawRecoveryTotal}, page showed ${originalPageTotal} new)`);
          } else {
            displayTotal = rawRecoveryTotal;
            console.log(`[SID] Adjusted displayTotal to ${displayTotal} (${thisRunDone()} done this run + ${unprocessedCount} remaining via API)`);
          }
          for (const s of submissions) {
            if (!running) break;
            // On new-only runs, stop once we've hit the page total
            if (isNewOnlyRun && originalPageTotal > 0 && thisRunDone() >= originalPageTotal) {
              console.log(`[SID] Recovery reached page total (${originalPageTotal}) — stopping`);
              break;
            }
            const legId = s.data?.legacyID;
            if (!legId || processed.has(legId)) continue;

            const displayName = cleanName(s.data?.profile?.name?.displayName || `Candidate ${legId.substring(0, 8)}`);
            totalProcessed++;

            // Try to get full React data from DOM; fall back to API data
            let reactData = getCandidateReactData(legId);
            if (!reactData) {
              const profile = s.data?.profile || {};
              reactData = {
                candidateSubmissionId: s.id,
                jobId: tryJobId,
                name: profile.name?.displayName || '',
                email: profile.contact?.email || '',
                phone: profile.contact?.phoneNumber || '',
                location: profile.location?.location || '',
                country: profile.location?.country || '',
                jobTitle: _cachedJobInfo.title,
                company: _cachedJobInfo.company,
                jobLocation: _cachedJobInfo.location,
                dateApplied: s.data?.created ? toEasternDateStr(s.data.created) : '',
                source: (() => {
                  const src = (s.data?.sources || [])[0] || {};
                  const attr = (src.attributionList || [])[0] || '';
                  if (attr === 'SPONSORED_JOBS' || (src.sourceType || '').includes('SPONSORED')) return 'Sponsored';
                  if (attr === 'ORGANIC_JOBS') return 'Organic';
                  return 'Unknown';
                })(),
                legacyId: legId,
                _fromAPI: true
              };
            }

            // Check international
            const candidateCountry = (reactData?.country || '').toUpperCase();
            const isInternational = candidateCountry && candidateCountry !== 'US' && candidateCountry !== 'CA';
            if (isInternational) {
              const loc = reactData?.location || 'Unknown location';
              addSkipped(legId, displayName, 'intl', loc + ' (' + candidateCountry + ')');
              skipped.add(legId); intlCount++;
              if (reactData) {
                csvRows.push({ ...reactData, resumeFile: '', notes: `International — ${loc} (${candidateCountry})` });
                await batchMarkAsReviewed([reactData], csrf);
                marked++;
              }
              processed.add(legId); persist(); updateStats();
              setProgress(widgetProcessed(), widgetTotal());
              updateTimeLeft(widgetTotal() - widgetProcessed(), thisRunDone());
              continue;
            }

            setStatus(`Processing: ${displayName}`);
            setProgress(widgetProcessed(), widgetTotal());
            updateTimeLeft(widgetTotal() - widgetProcessed(), thisRunDone());
            const result = await downloadResume(legId, displayName, csrf, reactData);
            const dlStatus = (typeof result === 'object') ? result.status : result;
            const actualFilename = (typeof result === 'object') ? result.filename : null;
            if (dlStatus === 'ok') {
              downloaded.add(legId); dlCount++;
              const fname = actualFilename || buildFilename(displayName, '', '', reactData);
              if (reactData) {
                csvRows.push({ ...reactData, resumeFile: fname, notes: '' });
              } else {
                csvRows.push({ name: displayName, legacyId: legId, jobTitle: _cachedJobInfo.title, company: _cachedJobInfo.company, jobLocation: _cachedJobInfo.location, resumeFile: fname, notes: 'Recovered via API' });
              }
              // Mark this recovered candidate as reviewed too
              if (reactData) {
                await batchMarkAsReviewed([reactData], csrf);
                marked++;
              }
            } else if (dlStatus === 'error') {
              skipped.add(legId);
              addSkipped(legId, displayName, 'error', 'Download failed');
              if (reactData) { await batchMarkAsReviewed([reactData], csrf); marked++; }
            } else {
              skipped.add(legId);
              addSkipped(legId, displayName, 'no_resume', '');
              if (reactData) { await batchMarkAsReviewed([reactData], csrf); marked++; }
            }
            processed.add(legId); persist(); updateStats();
            setProgress(widgetProcessed(), widgetTotal());
            updateTimeLeft(widgetTotal() - widgetProcessed(), thisRunDone());
            await randomWait(800, 1500);

            // Staggered session pauses to simulate human browsing
            const runCount = thisRunDone();
            if (runCount > 0 && runCount % 75 === 0) {
              // Longer pause every 75 candidates
              const pauseMs = Math.floor(Math.random() * 10001) + 10000; // 10-20s
              setStatus(`Brief pause (${Math.round(pauseMs / 1000)}s) — ${runCount} processed so far...`);
              console.log(`[SID] Session pause after ${runCount} candidates: ${Math.round(pauseMs / 1000)}s`);
              await wait(pauseMs);
            } else if (runCount > 0 && runCount % 25 === 0) {
              // Short pause every 25 candidates
              const pauseMs = Math.floor(Math.random() * 5001) + 5000; // 5-10s
              setStatus(`Brief pause (${Math.round(pauseMs / 1000)}s) — ${runCount} processed so far...`);
              console.log(`[SID] Short pause after ${runCount} candidates: ${Math.round(pauseMs / 1000)}s`);
              await wait(pauseMs);
            }
          }
          } catch (apiErr) {
            console.warn('[SID] Recovery API failed for this job ID:', apiErr.message);
          }
        }
      }
    }

    // ---- Summary ----
    const completed = widgetProcessed() >= (widgetTotal() || 0);
    const paused = !running && !completed; // user clicked Stop mid-way

    if (csvRows.length > 0) downloadZipBtn.style.display = 'block';
    updateDownloadAllBtn();
    setProgress(widgetProcessed(), widgetTotal() || widgetProcessed());

    if (paused) {
      // User paused — show Resume button, keep "Paused" status, show pause icon
      // (controlBtn already set to "Resume" by the click handler)
      const remaining = (widgetTotal() || 0) - widgetProcessed();
      setStatus(`Paused — ${dlCount} of ${widgetTotal() || '?'} done${remaining > 0 ? ` · ${remaining} left` : ''}`);
      if (statTimeLeft) {
        statTimeLeft.innerHTML = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" style="vertical-align:middle"><polygon points="10,1 17.66,4.34 17.66,15.66 10,19 2.34,15.66 2.34,4.34" fill="#fce4ec" stroke="#d08060" stroke-width="1.5" stroke-linejoin="round"/><rect x="7" y="6" width="2.5" height="8" rx="0.5" fill="#d08060"/><rect x="10.5" y="6" width="2.5" height="8" rx="0.5" fill="#d08060"/></svg>';
      }
    } else {
      // Finished or truly stopped — show Start button with full summary
      const thisRunSkipped = skipped.size - _statsBaselineSkipped;
      const noResumeCount = thisRunSkipped - intlCount - skippedDetails.filter(d => d.reason === 'error').length;
      let summary = completed
        ? (isNewOnlyRun ? `Done! ${dlCount} new resumes (${downloaded.size} total)` : `Done! ${dlCount} resumes ready`)
        : `Stopped — ${dlCount} of ${widgetTotal() || '?'} resumes`;
      if (intlCount > 0) summary += ` · ${intlCount} international`;
      if (noResumeCount > 0) summary += ` · ${noResumeCount} no resume`;
      if (skippedDetails.filter(d => d.reason === 'error').length > 0) summary += ` · ${skippedDetails.filter(d => d.reason === 'error').length} errors`;
      if (marked > 0) summary += ` · ${marked} reviewed`;
      setStatus(summary);
      updateStats(); // refresh stat boxes with this-run counts

      if (completed) playCompletionChime();

      // Flush any pending CSV data to IndexedDB
      flushCSV();

      running = false;
      controlBtn.textContent = 'Start';
      controlBtn.style.background = CSS.mintGrad;
      controlBtn.style.color = '#fff';
      if (statTimeLeft) {
        if (completed) {
          statTimeLeft.innerHTML = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" style="vertical-align:middle"><circle cx="10" cy="10" r="9" fill="#e6f5ec" stroke="#5cb88a" stroke-width="1.5"/><path d="M6 10.5l2.5 2.5 5.5-5.5" stroke="#5cb88a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        } else {
          statTimeLeft.innerHTML = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" style="vertical-align:middle"><polygon points="10,1 17.66,4.34 17.66,15.66 10,19 2.34,15.66 2.34,4.34" fill="#fce4ec" stroke="#d08060" stroke-width="1.5" stroke-linejoin="round"/><rect x="9" y="6" width="2" height="5" rx="1" fill="#d08060"/><circle cx="10" cy="13.5" r="1" fill="#d08060"/></svg>';
        }
      }
      // Show "start fresh" link so vendor can reset if needed
      if (statusFreshLink) statusFreshLink.style.display = 'block';
    }
    _runActive = false;
  }

  // ================================================
  // Init
  // ================================================
  createUI();
})();
